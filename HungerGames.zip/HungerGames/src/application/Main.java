/*
 * PAPAFOTIOU THEODOROS - AEM: 9708 - PHONE: 6977021300 - EMAIL: papafotit@ece.auth.gr
 * 
 * TATLI DIMITRA - AEM: 9802 - PHONE: 6971881071 - EMAIL: dimitatl@ece.auth.gr
 * 
 */

package application;
	
import java.util.HashMap;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;


public class Main extends Application {
	
	/*
	 * It puts green color in the rectangle of the weapon that 
	 * is taken from the player
	 */
	public void hasWeapon(Player p, String weapon, Rectangle r) {
		if(weapon == "pistol" && p.getPistol() != null) {
			r.setFill(Color.GREEN);
		}
		if(weapon == "sword" && p.getSword() != null) {
			r.setFill(Color.GREEN);
		}
		if(weapon == "bow" && p.getBow() != null) {
			r.setFill(Color.GREEN);
		}
	}
	
	/*
	 * It sets the size of the images
	 */
	public ImageView setImage(ImageView img) {
		img.setFitHeight(50); 
	    img.setFitWidth(50);
	    img.setPreserveRatio(true);
	    return img;
	}
	
	/*
	 * It puts an image given on the board which will be printed
	 */
	public ImageView putImage(Image image, int x, int y, Board boardGame) {
		ImageView img = new ImageView(image);
		int RecWid;
		int offset = 20;
		if (boardGame.getM() % 4 == 0) {
			RecWid = offset - (boardGame.getM() - offset)/4;
		}
		else {
			RecWid = offset - (boardGame.getM() + 2 - offset)/4;
		}
		
		int center = RecWid * 10;
		img.setFitHeight(RecWid); 
	    img.setFitWidth(RecWid);
	    int X, Y;
	    
	    if (x > 0) {
	    	if (y > 0) {
	    		X = center + RecWid * (y - 1);
	    		Y = center + RecWid * (x - 1);
	    	}
	    	else {
	    		X = center - RecWid * (Math.abs(y));
	    		Y = center + RecWid * (x - 1); 
	    	}
	    }
	    else {
	    	if (y > 0) {
	    		X = center + RecWid * (y - 1);
	    		Y = center - RecWid * (Math.abs(x));
	    	}
	    	else {
	    		X = center - RecWid * (Math.abs(y)); 
	    		Y = center - RecWid * (Math.abs(x));
	    	}
	    }
	    
	    img.setX(X);
	    img.setY(Y);
	    img.setPreserveRatio(true);
	    return img;
	}
	
	/*
	 * It creates the board which will be printed
	 */
	public Group createBoard(Board boardGame) {
		
		
	  	int A = boardGame.getA();
	  	int B = boardGame.getB();
	  	int C = boardGame.getC();
	  	int M = boardGame.getM();
	  	int RecWid;
	  	int offset = 20;
	  	if (M % 4 == 0) {
			RecWid = offset - (M - offset)/4;
		}
		else {
			RecWid = offset - (M + 2 - offset)/4;
		}
	  	int Ht = M * RecWid;
	  	int center = RecWid * 10;
	  	
	  	Group root = new Group();
	    
	    //creating and initializing the board
	    Rectangle board = new Rectangle();
	    	
	    board.setX(center - (Ht/2));
	    board.setY(center - (Ht/2));
	    board.setHeight(Ht);
	    board.setWidth(Ht);
	    
	    Rectangle trapsBoard = new Rectangle();

	    trapsBoard.setX(center - (C * RecWid));
	    trapsBoard.setY(center - (C * RecWid));
	    trapsBoard.setHeight(2 * C * RecWid);
	    trapsBoard.setWidth(2 * C * RecWid);
	    
	    Rectangle foodBoard = new Rectangle();

	    foodBoard.setX(center - (B * RecWid));
	    foodBoard.setY(center - (B * RecWid));
	    foodBoard.setHeight(2 * B * RecWid);
	    foodBoard.setWidth(2 * B * RecWid);
	    
	    Rectangle weaponsBoard = new Rectangle();

	    weaponsBoard.setX(center - (A * RecWid));
	    weaponsBoard.setY(center - (A * RecWid));
	    weaponsBoard.setHeight(2 * A * RecWid);
	    weaponsBoard.setWidth(2 * A * RecWid);
	    weaponsBoard.setFill(Color.ORANGE);
	    
	    Line[] lineT = new Line[M + 1];
	    Line[] lineN = new Line[M + 1];

	    for (int i = 0; i <= M ; i++) {
	    	lineT[i] = new Line();
	    	lineN[i] = new Line();
	    }
	    
	    for (int i = 0; i <= M ; i++) {

	    	lineT[i].setStartY(center - Ht/2 + (i * RecWid));
	    	lineT[i].setStartX(center - (Ht/2));
	    	lineT[i].setEndY(center - Ht/2 + (i * RecWid));
	    	lineT[i].setEndX(center + (Ht/2)); 
	    	
	    	lineN[i].setStartX(center - Ht/2 + (i * RecWid));
	    	lineN[i].setStartY(center - (Ht/2));
	    	lineN[i].setEndX(center - Ht/2 + (i * RecWid));
	    	lineN[i].setEndY(center + (Ht/2));
	    	
	    }
	    
	    if (M/2 > A && M/2 <= B) {

		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    if (M/2 > B && M/2 <= C) {

		    Shape board2 = Shape.subtract(trapsBoard, foodBoard);
		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board2.setFill(Color.DARKGREEN);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board2);
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    if (M/2 > C) {

		    Shape board1 = Shape.subtract(board, trapsBoard);
		    Shape board2 = Shape.subtract(trapsBoard, foodBoard);
		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board1.setFill(Color.DARKRED);
		    board2.setFill(Color.DARKGREEN);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board1);
		    root.getChildren().add(board2);
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    //put the traps in the right place
 	  	Image rope = new Image("rope2.png");
 	  	Image animal = new Image("animal.gif");
 	  	for (int i = 0; i < boardGame.getT(); i++) {
 	  		
 	  		if (Math.abs(boardGame.traps[i].getX()) <= C && Math.abs(boardGame.traps[i].getY()) <= C) {
	 	  		if(boardGame.traps[i].getType() == "ropes") {
	 	  			ImageView r = putImage(rope, boardGame.traps[i].getX(), 
	 	  					boardGame.traps[i].getY(), boardGame);
	 	  			root.getChildren().add(r);
	 	  		}
	 	  		else {
	 	  			ImageView a = putImage(animal, boardGame.traps[i].getX(), 
	 	  					boardGame.traps[i].getY(), boardGame);
	 	  			root.getChildren().add(a);
	 	  		}
 	  		}
 	  	}
 	  	
 	  	//put the weapons images in the right place
 	  	Image pistol1 = new Image("pistol1.png");
 	  	Image pistol2 = new Image("pistol2.png");
 	  	Image bow1 = new Image("bow1.png");
 	  	Image bow2 = new Image("bow2.png");
 	  	Image sword1 = new Image("sword1.png");
 	  	Image sword2 = new Image("sword2.png");

 	  	for(int i = 0; i < boardGame.getW(); i++) {
 	  		
 	  		System.out.println(boardGame.weapons[i].getX() + "\t" + boardGame.weapons[i].getY()); 
 	  		if(boardGame.weapons[i].getX() == 0 && boardGame.weapons[i].getY() == 0) {
 	  			continue;
 	  		}
 	  		
 	  		if(boardGame.weapons[i].getType() == "pistol") {
 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
 	  				ImageView pis1 = putImage(pistol1, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(pis1);		
 	  			}
 	  			else {
 	  				ImageView pis2 = putImage(pistol2, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(pis2);	
 	  			}
 	  		}
 	  		if(boardGame.weapons[i].getType() == "bow") {
 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
 	  				ImageView b1 = putImage(bow1, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(b1);		
 	  			}
 	  			else {
 	  				ImageView b2 = putImage(bow2, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(b2);	
 	  			}
 	  		}
 	  		if(boardGame.weapons[i].getType() == "sword") {
 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
 	  				ImageView s1 = putImage(sword1, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(s1);		
 	  			}
 	  			else {
 	  				ImageView s2 = putImage(sword2, boardGame.weapons[i].getX(), 
 	  						boardGame.weapons[i].getY(), boardGame);
 	  				root.getChildren().add(s2);	
 	  			}
 	  		}
 	  	}
 	  	System.out.println();
 	  	
 	  	Image cherrypie = new Image("cherrypie.png");
	  	Image donut = new Image("donut.png");
	  	Image grapes = new Image("grapes.png");
	  	Image hamburger = new Image("hamburger.png");
	  	Image pancakes = new Image("pancakes.png");
	  	Image pizzaslice = new Image("pizza-slice.png");
	  	Image pizza = new Image("pizza.png");
	  	Image strawberry = new Image("strawberry.png");
	  	Image corn = new Image("corn.png");
	  	Image mushrooms = new Image("mushrooms.png");
	  	
	  	HashMap<Integer, Image> foodmap = new HashMap<Integer, Image>();
	  	foodmap.put(1, corn);
	  	foodmap.put(2, strawberry);
	  	foodmap.put(3, grapes);
	  	foodmap.put(4, mushrooms);
	  	foodmap.put(5, pizzaslice);
	  	foodmap.put(6, cherrypie);
	  	foodmap.put(7, pancakes);
	  	foodmap.put(8, donut);
	  	foodmap.put(9, hamburger);
	  	foodmap.put(10, pizza);
	  	
	  	for(int i = 0; i < boardGame.getF(); i++) {
	  		
	  		if(boardGame.food[i].getX() == 0 && boardGame.food[i].getY() == 0) {
 	  			continue;
 	  		}
    	  		Image u = foodmap.get(boardGame.food[i].getPoints());
    	  		if (Math.abs(boardGame.food[i].getX()) <= B && Math.abs(boardGame.food[i].getY()) <= B) {
	    	  		ImageView f = putImage(u, boardGame.food[i].getX(),
	    	  				boardGame.food[i].getY(), boardGame);
	    	  		root.getChildren().add(f);
    	  		}
	  	}
	    return root;
	}
	
	/*
	 *	It returns the distance from the object we want (player, weapon, food, trap) 
	 *
	 *  Since we calculate the Cartesian distance, the distance = [1,2) is the field r = 1 around the player,
	 *  the distance = [2, 3) is the field r = 2 around the player etc
	 */
	public float distanceFrom(int xx, int yy, ManualPlayer p) {
		
		int m, n, s, t;
		
		if(p.getX()*xx > 0 && p.getY()*yy > 0) {		// if player and object are on the same quadrant
			m = p.getX();
			n = xx;
			s = p.getY();
			t = yy;
		}
		else if(p.getX()*xx > 0 && p.getY()*yy < 0) {	// if player and object are on the quadrant 1 - 2, 3 - 4 relatively (and vice versa)	
			m = p.getX();
			n = xx;
			if (p.getY() < 0) {
				s = p.getY() + 1;
				t = yy;
			}
			else {
				s = p.getY();
				t = yy + 1;
			}
		}
		else if(p.getX()*xx < 0 && p.getY()*yy > 0) {	// if player and object are on the quadrant 1 - 4, 2 - 3 relatively (and vice versa)
		    s = p.getY();
			t = yy;
			if (p.getX() < 0) {
				m = p.getX() + 1;
				n = xx;
			}
			else {
				m = p.getX();
				n = xx + 1;
			}
		}	
		else {							// if player and object are on the quadrant 1 - 3, 2 - 4 relatively (and vice versa)
			if (p.getX() < 0) {
				m = p.getX() + 1;
				n = xx;
			}
			else {
				m = p.getX();
				n = xx + 1;
			}
			
			if (p.getY() < 0) {
				s = p.getY() + 1;
				t = yy;
			}
			else {
				s = p.getY();
				t = yy + 1;
			}
		}
			
		float distance = (float)Math.sqrt(Math.pow(m - n, 2) + Math.pow(s - t, 2));
		
		for (int i = 1; i <= p.getR(); i++) {
			if (distance >= i && distance < (i + 1)) {
				distance = i;
			}
		}
	
		if (distance < (p.getR() + 1)) 
			return distance;
		
		else 
			return -1;
	}
	
	/*
	 * It creates the board which will be printed. The difference from the
	 * function above is that this board is used when we play with the manual player
	 * (since he can see only in a range of R around him)
	 */
	public Group createBoardHuman(Board boardGame, ManualPlayer player) {
		
		
	  	int A = boardGame.getA();
	  	int B = boardGame.getB();
	  	int C = boardGame.getC();
	  	int M = boardGame.getM();
	  	int RecWid;
	  	int offset = 20;
	  	if (M % 4 == 0) {
			RecWid = offset - (M - offset)/4;
		}
		else {
			RecWid = offset - (M - offset)/4;
		}

	  	int Ht = M * RecWid;
	  	int center = RecWid * 10;
	  	
	  	Group root = new Group();
	    
	    //creating and initializing the board
	    Rectangle board = new Rectangle();
	    	
	    board.setX(center - (Ht/2));
	    board.setY(center - (Ht/2));
	    board.setHeight(Ht);
	    board.setWidth(Ht);
	    
	    Rectangle trapsBoard = new Rectangle();

	    trapsBoard.setX(center - (C * RecWid));
	    trapsBoard.setY(center - (C * RecWid));
	    trapsBoard.setHeight(2 * C * RecWid);
	    trapsBoard.setWidth(2 * C * RecWid);
	    
	    Rectangle foodBoard = new Rectangle();

	    foodBoard.setX(center - (B * RecWid));
	    foodBoard.setY(center - (B * RecWid));
	    foodBoard.setHeight(2 * B * RecWid);
	    foodBoard.setWidth(2 * B * RecWid);
	    
	    Rectangle weaponsBoard = new Rectangle();

	    weaponsBoard.setX(center - (A * RecWid));
	    weaponsBoard.setY(center - (A * RecWid));
	    weaponsBoard.setHeight(2 * A * RecWid);
	    weaponsBoard.setWidth(2 * A * RecWid);
	    weaponsBoard.setFill(Color.ORANGE);
	    
	    Line[] lineT = new Line[M + 1];
	    Line[] lineN = new Line[M + 1];

	    for (int i = 0; i <= M ; i++) {
	    	lineT[i] = new Line();
	    	lineN[i] = new Line();
	    }
	    
	    for (int i = 0; i <= M ; i++) {

	    	lineT[i].setStartY(center - Ht/2 + (i * RecWid));
	    	lineT[i].setStartX(center - (Ht/2));
	    	lineT[i].setEndY(center - Ht/2 + (i * RecWid));
	    	lineT[i].setEndX(center + (Ht/2)); 
	    	
	    	lineN[i].setStartX(center - Ht/2 + (i * RecWid));
	    	lineN[i].setStartY(center - (Ht/2));
	    	lineN[i].setEndX(center - Ht/2 + (i * RecWid));
	    	lineN[i].setEndY(center + (Ht/2));
	    	
	    }
	    
	    if (M/2 > A && M/2 <= B) {

		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    if (M/2 > B && M/2 <= C) {

		    Shape board2 = Shape.subtract(trapsBoard, foodBoard);
		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board2.setFill(Color.DARKGREEN);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board2);
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    if (M/2 > C) {

		    Shape board1 = Shape.subtract(board, trapsBoard);
		    Shape board2 = Shape.subtract(trapsBoard, foodBoard);
		    Shape board3 = Shape.subtract(foodBoard,  weaponsBoard);
		    board1.setFill(Color.DARKRED);
		    board2.setFill(Color.DARKGREEN);
		    board3.setFill(Color.DARKBLUE);
		    
		    root.getChildren().add(board1);
		    root.getChildren().add(board2);
		    root.getChildren().add(board3);
		    root.getChildren().add(weaponsBoard);
		    for (int i = 0; i <= M; i++) {
		    	root.getChildren().add(lineN[i]);
		    	root.getChildren().add(lineT[i]);
		    }
	    }
	    
	    //put the traps in the right place
 	  	Image rope = new Image("rope2.png");
 	  	Image animal = new Image("animal.gif");
 	  	for (int i = 0; i < boardGame.getT(); i++) {
 	  		
 	  		if (Math.abs(boardGame.traps[i].getX()) <= C && Math.abs(boardGame.traps[i].getY()) <= C
 	  				&& distanceFrom(boardGame.traps[i].getX(), boardGame.traps[i].getY(), player) > 0) {
	 	  		if(boardGame.traps[i].getType() == "ropes") {
	 	  			ImageView r = putImage(rope, boardGame.traps[i].getX(), 
	 	  					boardGame.traps[i].getY(), boardGame);
	 	  			root.getChildren().add(r);
	 	  		}
	 	  		else {
	 	  			ImageView a = putImage(animal, boardGame.traps[i].getX(), 
	 	  					boardGame.traps[i].getY(), boardGame);
	 	  			root.getChildren().add(a);
	 	  		}
 	  		}
 	  	}
 	  	
 	  	//put the weapons images in the right place
 	  	Image pistol1 = new Image("pistol1.png");
 	  	Image pistol2 = new Image("pistol2.png");
 	  	Image bow1 = new Image("bow1.png");
 	  	Image bow2 = new Image("bow2.png");
 	  	Image sword1 = new Image("sword1.png");
 	  	Image sword2 = new Image("sword2.png");

 	  	for(int i = 0; i < boardGame.getW(); i++) {
 	  		
 	  		if (distanceFrom(boardGame.weapons[i].getX(), boardGame.weapons[i].getY(), player) > 0) {
	 	  		
 	  			if(boardGame.weapons[i].getX() == 0 && boardGame.weapons[i].getY() == 0) {
	 	  			continue;
	 	  		}
	 	  		
	 	  		if(boardGame.weapons[i].getType() == "pistol") {
	 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
	 	  				ImageView pis1 = putImage(pistol1, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(pis1);		
	 	  			}
	 	  			else {
	 	  				ImageView pis2 = putImage(pistol2, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(pis2);	
	 	  			}
	 	  		}
	 	  		if(boardGame.weapons[i].getType() == "bow") {
	 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
	 	  				ImageView b1 = putImage(bow1, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(b1);		
	 	  			}
	 	  			else {
	 	  				ImageView b2 = putImage(bow2, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(b2);	
	 	  			}
	 	  		}
	 	  		if(boardGame.weapons[i].getType() == "sword") {
	 	  			if(boardGame.weapons[i].getPlayerId() == 1) {
	 	  				ImageView s1 = putImage(sword1, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(s1);		
	 	  			}
	 	  			else {
	 	  				ImageView s2 = putImage(sword2, boardGame.weapons[i].getX(), 
	 	  						boardGame.weapons[i].getY(), boardGame);
	 	  				root.getChildren().add(s2);	
	 	  			}
	 	  		}
 	  		}
 	  	}
 	  	
 	  	Image cherrypie = new Image("cherrypie.png");
	  	Image donut = new Image("donut.png");
	  	Image grapes = new Image("grapes.png");
	  	Image hamburger = new Image("hamburger.png");
	  	Image pancakes = new Image("pancakes.png");
	  	Image pizzaslice = new Image("pizza-slice.png");
	  	Image pizza = new Image("pizza.png");
	  	Image strawberry = new Image("strawberry.png");
	  	Image corn = new Image("corn.png");
	  	Image mushrooms = new Image("mushrooms.png");
	  	
	  	HashMap<Integer, Image> foodmap = new HashMap<Integer, Image>();
	  	foodmap.put(1, corn);
	  	foodmap.put(2, strawberry);
	  	foodmap.put(3, grapes);
	  	foodmap.put(4, mushrooms);
	  	foodmap.put(5, pizzaslice);
	  	foodmap.put(6, cherrypie);
	  	foodmap.put(7, pancakes);
	  	foodmap.put(8, donut);
	  	foodmap.put(9, hamburger);
	  	foodmap.put(10, pizza);
	  	
	  	for(int i = 0; i < boardGame.getF(); i++) {
	  		
	  		if(boardGame.food[i].getX() == 0 && boardGame.food[i].getY() == 0) {
 	  			continue;
 	  		}
    	  	Image u = foodmap.get(boardGame.food[i].getPoints());
    	  	if (Math.abs(boardGame.food[i].getX()) <= B && Math.abs(boardGame.food[i].getY()) <= B 
    	  			&& distanceFrom(boardGame.food[i].getX(), boardGame.food[i].getY(), player) > 0) {
	    	  	ImageView f = putImage(u, boardGame.food[i].getX(),
	    	  			boardGame.food[i].getY(), boardGame);
	    	  	root.getChildren().add(f);
    	  	}
	  	}
	    return root;
	}
	
	/*
	 * It returns the last scene printed, when the game is over
	 */
	public Scene windowLastMessage(Text[] text, Button close) {
	
		GridPane pane = createGridPane();
	    Group root = new Group();
	    ImageView img = new ImageView(new Image("finalimg.png"));
	    root.getChildren().add(img);

	    if (text[1] == null) {
	    	text[0].setStyle("-fx-font: normal bold 25px 'serif' ");
	    	text[0].setFill(Color.BLACK);  
	    	text[0].setX(100);
	    	text[0].setY(200);
	    	root.getChildren().add(text[0]);
		    pane.add(root, 0, 0);
		    pane.add(close, 0, 1);
	    }
	    
	    else {
	    	text[0].setStyle("-fx-font: normal bold 25px 'serif' ");
	    	text[1].setStyle("-fx-font: normal bold 25px 'serif' ");
	    	text[2].setStyle("-fx-font: normal bold 25px 'serif' ");
	    	text[0].setFill(Color.BLACK);    
		    text[1].setFill(Color.BLACK);	    
		    text[2].setFill(Color.BLACK);
	    	
		    for(int i = 0; i < 3; i++) {
		    	text[i].setX(100);
		    	text[i].setY(200 + i * 60);
		    	root.getChildren().add(text[i]);
		    }
		    pane.add(root, 0, 0);
		    pane.add(close, 0, 1);
		    
	    }
	    Scene windowMessage = new Scene(pane, 1200, 800);
	    
	    return windowMessage;
	}
	
	/*
	 * It creates a grid-pane
	 */
	public GridPane createGridPane() {

	    GridPane pane = new GridPane();
	    
	    //Setting size for the pane 
	    pane.setMinSize(1200, 800); 
	       
	    //Setting the padding    
	    pane.setPadding(new Insets(20, 20, 20, 20));  
	      
	    //Setting the vertical and horizontal gaps between the columns 
	    pane.setVgap(13); 
	    pane.setHgap(13);       
	      
	    //Setting the Grid alignment 
	    pane.setAlignment(Pos.CENTER);
	    
	    //Setting the back ground color 
        pane.setStyle("-fx-background-color: CADETBLUE;");

	    return pane;
	}
	
	/*
	 * It sets the turn of each player
	 */
	public int setTurns(int a) {
		if (a == 1) {
			return 0;
		}
		else 
			return 1;
	}

	/*
	 * It indicates if the dice (taken as an input) leads to an allowed move 
	 * It returns true if the move is allowed, false if not
	 */
	public boolean isAllowed(int k, Board boardGame, Player p) {
		
		int M = boardGame.getM();
		int N = boardGame.getN();
		int x = p.getX();
		int y = p.getY();
			
			if (y == -N/2 && x != M/2 && x != -M/2) {			//if in left side, NO corners
				if (k < 6) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (y == N/2 && x != M/2 && x != -M/2) {		//if in right side, NO corners
				if (k == 1 || k > 4) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y != N/2 && y != -N/2) {		//if in down side, NO corners
				if (k < 4 || k > 6) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y != N/2 && y != -N/2) {		//if in up side, NO corners
				if (k > 2 && k < 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y == N/2) {					//if in up right corner
				if (k > 4 && k < 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y == N/2) {					//if in down right corner
				if (k == 1 || k == 7 || k == 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y == -N/2) {					//if in down left corner
				if (k < 4) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y == -N/2) {					//if in up left corner
				if (k == 3 || k == 4 || k == 5) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
	}
	
	/*
	 * It returns a group of the buttons (dice-choosers) 
	 * putting the on the right position
	 */
	public Group createButtonGroup(Button up, Button upRight, Button right, Button downRight, 
										Button down, Button downLeft, Button left, Button upLeft,
											Board boardGame, Player p) {
		Group root = new Group();
		Circle circle = new Circle(240, 220, 110);
		circle.setFill(Color.DARKRED);
		
		int center = 200;
		int offset = 80;

		up.setShape(new Circle(10));
		upRight.setShape(new Circle(10));
		right.setShape(new Circle(10));
		downRight.setShape(new Circle(10));
		down.setShape(new Circle(10));
		downLeft.setShape(new Circle(10));
		left.setShape(new Circle(10));
		upLeft.setShape(new Circle(10));
		
		up.setLayoutX(center + 20);
		up.setLayoutY(center - offset + 20);
		upRight.setLayoutX(center + offset/2);
		upRight.setLayoutY(center - offset/2 + 10);
		right.setLayoutX(center + offset - 5);
		right.setLayoutY(center);
		downRight.setLayoutX(center + offset/2);
		downRight.setLayoutY(center + offset/2 - 10);
		down.setLayoutX(center);
		down.setLayoutY(center + offset - 20);
		downLeft.setLayoutX(center - offset/2 );
		downLeft.setLayoutY(center + offset/2 - 10);
		left.setLayoutX(center - offset + 15);
		left.setLayoutY(center);
		upLeft.setLayoutX(center - offset/2);
		upLeft.setLayoutY(center - offset/2 + 10);
		
		root.getChildren().add(circle);
		if (isAllowed(1, boardGame, p)) {
			root.getChildren().add(up);
		}
		if (isAllowed(2, boardGame, p)) {
			root.getChildren().add(upRight);
		}
		if (isAllowed(3, boardGame, p)) {
			root.getChildren().add(right);
		}
		if (isAllowed(4, boardGame, p)) {
			root.getChildren().add(downRight);
		}
		if (isAllowed(5, boardGame, p)) {
			root.getChildren().add(down);
		}
		if (isAllowed(6, boardGame, p)) {
			root.getChildren().add(downLeft);
		}
		if (isAllowed(7, boardGame, p)) {
			root.getChildren().add(left);
		}
		if (isAllowed(8, boardGame, p)) {
			root.getChildren().add(upLeft);
		}
		
		
		return root;
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			primaryStage.setMaxWidth(1600);
			primaryStage.setMaxHeight(900);
			
			Image[] charImg = new Image[2];
			
			//Label for name 
		    Text nameLabel = new Text("Observer Name"); 
		      
		    //Text field for name 
		    TextField nameText = new TextField(); 
		       
		    //Label for gender of player 1
		    Text genderLabel1 = new Text("Player 1 Gender"); 
		      
		    //Toggle group of radio buttons for the gender of player 1       
		    ToggleGroup groupGender1 = new ToggleGroup(); 
		    RadioButton maleRadio1 = new RadioButton("Male"); 
		    maleRadio1.setToggleGroup(groupGender1); 
		    groupGender1.selectToggle(maleRadio1);

		    RadioButton femaleRadio1 = new RadioButton("Female"); 
		    femaleRadio1.setToggleGroup(groupGender1); 
		    
		    RadioButton neutralRadio1 = new RadioButton("Other"); 
		    neutralRadio1.setToggleGroup(groupGender1);
		    
		    //Label for gender of player 2
		    Text genderLabel2 = new Text("Player 2 Gender"); 
		    
		    //Toggle group of radio buttons for the gender of player 2    
		    ToggleGroup groupGender2 = new ToggleGroup(); 
		    RadioButton maleRadio2 = new RadioButton("Male"); 
		    maleRadio2.setToggleGroup(groupGender2); 
		    
		    RadioButton femaleRadio2 = new RadioButton("Female"); 
		    femaleRadio2.setToggleGroup(groupGender2);
		    groupGender2.selectToggle(femaleRadio2);
		    
		    RadioButton neutralRadio2 = new RadioButton("Other"); 
		    neutralRadio2.setToggleGroup(groupGender2);

		    Text player1Label = new Text("Player 1"); 
		      
		    //Choice box for the type of player 1
		    ChoiceBox<String> player1choiceBox = new ChoiceBox<>();
		    player1choiceBox.getItems().addAll ("Heuristic", "Random", "MinMax", "Manual"); 
		    player1choiceBox.getSelectionModel().select(0);
		    
		    Text player2Label = new Text("Player 2"); 
		      
		    //Choice box for the type of player 2
		    ChoiceBox<String> player2choiceBox = new ChoiceBox<>(); 
		    player2choiceBox.getItems().addAll ("Heuristic", "Random", "MinMax", "Manual"); 
		    player2choiceBox.getSelectionModel().select(0);

		    
		    Text sizeBoard = new Text("Choose the size of the board (number x number)");
		    
		    
		    ChoiceBox<Integer> chooseSize1 = new ChoiceBox<>();
		    chooseSize1.getItems().addAll(18, 20, 24, 28, 32, 36);
		    chooseSize1.getSelectionModel().select(0);

		    
		    //Label for WSize 
		    Text WSize = new Text("Choose the size of the Weapons-Board (number x number)");
		    ChoiceBox<Integer> chooseSize2 = new ChoiceBox<>();
		    chooseSize2.getItems().addAll(4, 6, 8, 10, 12, 14);
		    chooseSize2.getSelectionModel().select(0);

		    
		    //Label for FSize 
		    Text FSize = new Text("Choose the size of the Food-Board (number x number)");
		    ChoiceBox<Integer> chooseSize3 = new ChoiceBox<>();
		    chooseSize3.getItems().addAll(6, 8, 10, 12, 14, 16);
		    chooseSize3.getSelectionModel().select(0);

		    Text attention1 = new Text("Give a number bigger than the weapons-board's size!");
		    attention1.setFont(Font.font ("Verdana", FontPosture.ITALIC, 15.0));
		    //Label for TSize 
		    Text TSize = new Text("Choose the size of the Traps-Board (number x number)");
		    ChoiceBox<Integer> chooseSize4 = new ChoiceBox<>();
		    chooseSize4.getItems().addAll(8, 10, 12, 14, 16, 18);
		    chooseSize4.getSelectionModel().select(0);

		    Text attention2 = new Text("Give a number bigger than the food-board's size!");
		    attention2.setFont(Font.font ("Verdana", FontPosture.ITALIC, 15.0));
		    
		    Text numOfTraps = new Text("How many traps do you want to put on the board?");
		    //Creating a scrollBar 
		    ScrollBar scrollTraps = new ScrollBar();
		    scrollTraps.setMin(1);
		    scrollTraps.setMax(50);
		    scrollTraps.setValue(20);

		    
		    Text numOfFood = new Text("How many foodElements do you want to put on the board?");
		    //Creating a scrollBar 
		    ScrollBar scrollFood = new ScrollBar();
		    scrollFood.setMin(1);
		    scrollFood.setMax(40);
		    scrollFood.setValue(15);
		    
		    
		    //The buttons of the runtime
		    Button buttonPlayHH = new Button("PLAY HEURISTIC-HEURISTIC");
		    Button buttonPlayHM = new Button("PLAY HEURISTIC-MINMAX");
		    Button buttonPlayMH = new Button("PLAY MINMAX-HEURISTIC");
		    Button buttonPlayHR = new Button("PLAY HEURISTIC-RANDOM");
		    Button buttonPlayRH = new Button("PLAY RANDOM-HEURISTIC");
		    Button buttonPlayRR = new Button("PLAY RANDOM-RANDOM");
		    Button buttonPlayMM = new Button("PLAY MINMAX-MINMAX");
		    Button buttonPlayMR = new Button("PLAY MINMAX-RANDOM");
		    Button buttonPlayRM = new Button("PLAY RANDOM-MINMAX");
		    Button buttonPlayRP = new Button("PLAY RANDOM");
		    Button buttonPlayHP = new Button("PLAY HEURISTIC");
		    Button buttonPlayMP = new Button("PLAY MINMAX");
		    Button buttonPlayPR = new Button("PLAY RANDOM");
		    Button buttonPlayPH = new Button("PLAY HEURISTIC");
		    Button buttonPlayPM = new Button("PLAY MINMAX");
		    Button submitButton = new Button("SUBMIT CHANGES");
		    Button submitSizes = new Button("SUBMIT SIZES");
		    Button buttonError = new Button("SUBMIT AGAIN");
		    Button buttonTerminate = new Button("TERMINATE");

			Button up = new Button("UP");
			Button upRight = new Button("U-RIGHT");
			Button right = new Button("RIGHT");
			Button downRight = new Button("D-RIGHT");
			Button down = new Button("DOWN");
			Button downLeft = new Button("D-LEFT");
			Button left = new Button("LEFT");
			Button upLeft = new Button("U-LEFT");
	        
		    //Styling nodes   
		      
	        nameLabel.setStyle("-fx-font: normal bold 20px 'serif' "); 
	        genderLabel1.setStyle("-fx-font: normal bold 20px 'serif' ");
	        genderLabel2.setStyle("-fx-font: normal bold 20px 'serif' ");
	        player1Label.setStyle("-fx-font: normal bold 20px 'serif' ");
	        player2Label.setStyle("-fx-font: normal bold 20px 'serif' ");
	        sizeBoard.setStyle("-fx-font: normal bold 20px 'serif' ");
	        WSize.setStyle("-fx-font: normal bold 20px 'serif' ");
	        FSize.setStyle("-fx-font: normal bold 20px 'serif' ");
	        TSize.setStyle("-fx-font: normal bold 20px 'serif' ");
	        numOfTraps.setStyle("-fx-font: normal bold 20px 'serif' ");
	        numOfFood.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayHH.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayHM.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayMH.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayRR.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayHR.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayRH.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayPR.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayPH.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayPM.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayRP.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayHP.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayMP.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayRM.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayMR.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonPlayMM.setStyle("-fx-font: normal bold 20px 'serif' ");
	        submitButton.setStyle("-fx-font: normal bold 20px 'serif' ");
	        submitSizes.setStyle("-fx-font: normal bold 20px 'serif' ");
	        buttonError.setStyle("-fx-font: normal bold 20px 'serif' ");
		    buttonTerminate.setStyle("-fx-font: normal bold 15px 'serif' ");
		    up.setStyle("-fx-font: normal bold 15px 'serif' ");
		    upRight.setStyle("-fx-font: normal bold 15px 'serif' ");
		    right.setStyle("-fx-font: normal bold 15px 'serif' ");
		    downRight.setStyle("-fx-font: normal bold 15px 'serif' ");
		    down.setStyle("-fx-font: normal bold 15px 'serif' ");
		    downLeft.setStyle("-fx-font: normal bold 15px 'serif' ");
		    left.setStyle("-fx-font: normal bold 15px 'serif' ");
		    upLeft.setStyle("-fx-font: normal bold 15px 'serif' ");

		      
		    //when Terminate is clicked...
		    buttonTerminate.setOnMouseClicked((new EventHandler<MouseEvent>() { 
		          public void handle(MouseEvent event) { 
		             System.out.println("Ok, I will terminate the game."); 
		             primaryStage.close();
		          } 
		    }));
		    
		    
		    //Character Images of Players
		    ImageView char1 = new ImageView(new Image("male1.png"));
		    char1 = setImage(char1);
		    ImageView char2 = new ImageView(new Image("female1.png"));
		    char2 = setImage(char2);
		    ImageView char3 = new ImageView(new Image("other1.png"));
		    char3 = setImage(char3);
		    ImageView char4 = new ImageView(new Image("male2.png"));
		    char4 = setImage(char4);
		    ImageView char5 = new ImageView(new Image("female2.png"));
		    char5 = setImage(char5);
		    ImageView char6 = new ImageView(new Image("other2.png"));
		    char6 = setImage(char6);

		    //Creating a Grid Pane 
	        GridPane gridPane = createGridPane();    

	        //Arranging all the nodes in the grid 
	        gridPane.add(nameLabel, 1, 0); 
	        gridPane.add(nameText, 1, 1); 
	        gridPane.add(player1Label, 1, 2);
	        gridPane.add(player2Label, 3, 2);
	        gridPane.add(player1choiceBox, 1, 3);
		    gridPane.add(player2choiceBox, 3, 3);
		    gridPane.add(genderLabel1, 1, 4); 
		    gridPane.add(maleRadio1, 1, 5);       
		    gridPane.add(femaleRadio1, 1, 6);
		    gridPane.add(neutralRadio1, 1, 7);
		    gridPane.add(genderLabel2, 3, 4); 
		    gridPane.add(maleRadio2, 3, 5);       
		    gridPane.add(femaleRadio2, 3, 6);
		    gridPane.add(neutralRadio2, 3, 7);
		    gridPane.add(sizeBoard, 1, 8);
		    gridPane.add(chooseSize1, 3, 8);
		    gridPane.add(WSize, 1, 9);
		    gridPane.add(chooseSize2, 3, 9);
		    gridPane.add(FSize, 1, 10);
		    gridPane.add(attention1, 1, 11);
		    gridPane.add(chooseSize3, 3, 10);
		    gridPane.add(TSize, 1, 12);
		    gridPane.add(chooseSize4, 3, 12);
		    gridPane.add(attention2, 1, 13);
		    gridPane.add(numOfTraps, 1, 15);
		    gridPane.add(scrollTraps, 3, 15);
		    gridPane.add(numOfFood, 1, 14);
		    gridPane.add(scrollFood, 3, 14);
		    gridPane.add(submitButton, 1, 16);
		    gridPane.add(buttonTerminate, 1, 17);
		    gridPane.add(char1, 0, 5);
		    gridPane.add(char2, 0, 6);
		    gridPane.add(char3, 0, 7);
		    gridPane.add(char4, 2, 5);
		    gridPane.add(char5, 2, 6);
		    gridPane.add(char6, 2, 7);

	        Scene beginScene = new Scene(gridPane, 1200, 800);
			
			//Setting title to the Stage 
		    primaryStage.setTitle("HUNGER GAMES REMASTERED"); 
        	primaryStage.setFullScreen(true);
		    primaryStage.setScene(beginScene);
			primaryStage.show();
	        
			System.out.println("Hello World");  
			Game game = new Game();
			final Board boardGame = new Board();
			final Player p1 = new Player();
			
			//creating players of all types
			final HeuristicPlayer p11 = new HeuristicPlayer();
			final MinMaxPlayer p111 = new MinMaxPlayer();
			final ManualPlayer p1111 = new ManualPlayer();
			
			final Player p2 = new Player();
			final HeuristicPlayer p22 = new HeuristicPlayer();
			final MinMaxPlayer p222 = new MinMaxPlayer();
			final ManualPlayer p2222 = new ManualPlayer();
			
			//when buttonError button is clicked...
		    buttonError.setOnMousePressed(event -> {
		    	String type1 = player1choiceBox.getValue().toString();
		    	String type2 = player2choiceBox.getValue().toString();
		    	
		    	if (type1 == "Manual" && type2 == "Manual"){
		    		
		    		Text errorMessage1 = new Text("The players you chose can't play together (again)!");
	        		Text errorMessage2 = new Text("Choose an other combination of players: ");
	        		Text errorMessage3 = new Text("The playable compinations are all apart from: ");
	        		Text errorMessage4 = new Text("Manual - Manual");
	        		errorMessage1.setStyle("-fx-font: normal bold 20px 'serif' ");
	        		errorMessage2.setStyle("-fx-font: normal bold 20px 'serif' ");
	        		errorMessage3.setStyle("-fx-font: normal bold 20px 'serif' ");
	        		errorMessage4.setStyle("-fx-font: normal bold 20px 'serif' ");
	        		//Creating a Grid Pane 
	     	        GridPane errorPane = createGridPane(); 
	     	        errorPane.add(errorMessage1, 0, 0);
	     	        errorPane.add(errorMessage2, 0, 1);
	     	        errorPane.add(errorMessage3, 0, 2);
	     	        errorPane.add(errorMessage4, 1, 2);
	     	        errorPane.add(player1Label, 0, 4);
	     	        errorPane.add(player2Label, 1, 4);
	     	        errorPane.add(player1choiceBox, 0, 5);
	     	        errorPane.add(player2choiceBox, 1, 5);
	     	        errorPane.add(buttonError, 0, 6);
	    		    Scene errorScene = new Scene(errorPane, 1200, 800);
		        	primaryStage.setScene(errorScene);
		        	primaryStage.setFullScreen(true);
					primaryStage.show();
		    	}
		    	else {
		    		Text rightMessage1 = new Text("Congratulations! You chose a right combination!");
		    		Text rightMessage2 = new Text("YOU ARE SOOO SMART!");
		    		Text rightMessage3 = new Text("Press submit: ");
		    		rightMessage1.setStyle("-fx-font: normal bold 25px 'serif' ");
		    		rightMessage2.setStyle("-fx-font: normal bold 25px 'serif' ");
		    		rightMessage3.setStyle("-fx-font: normal bold 25px 'serif' ");
		    		GridPane rightPane = createGridPane();
		    	    rightPane.add(rightMessage1, 0, 0);
		    	    rightPane.add(rightMessage2, 0, 1);
		    	    rightPane.add(rightMessage3, 0, 2);
		    	    rightPane.add(submitButton, 0, 4);
		    	    Scene rightScene = new Scene(rightPane, 1200, 800);
		        	primaryStage.setScene(rightScene);
		        	primaryStage.setFullScreen(true);
					primaryStage.show();
		    	}
		    });
		    
		    submitSizes.setOnMouseClicked((new EventHandler<MouseEvent>() { 
		          public void handle(MouseEvent event) { 
			    	int M = chooseSize1.getValue();
			    	int W_L = chooseSize2.getValue();
			    	int F_L = chooseSize3.getValue();
			    	int T_L = chooseSize4.getValue();
			    	int F = (int)scrollFood.getValue();
		        	int T = (int)scrollTraps.getValue();
			    	
			    	if (W_L >= F_L || F_L >= T_L) {
		        		Text errorMessage1 = new Text("The sizes you gave cannot create a board (again)!");
		        		Text errorMessage2 = new Text("Choose an other combination of sizes: ");
		        		Text errorMessage3 = new Text("The sizes must be as below: ");
		        		Text errorMessage4 = new Text("Weapons-Board size < Food-Board size < Trap-Board size");
		        		errorMessage1.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage2.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage3.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage4.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		
		        		//Creating a Grid Pane 
		        		chooseSize2.setValue(null);
		        		chooseSize3.setValue(null);
		        		chooseSize4.setValue(null);
		     	        GridPane errorPane = createGridPane(); 
		     	        errorPane.add(errorMessage1, 0, 0);
		     	        errorPane.add(errorMessage2, 0, 1);
		     	        errorPane.add(errorMessage3, 0, 2);
		     	        errorPane.add(errorMessage4, 1, 2);
		     	        errorPane.add(WSize, 0, 4);
		     	        errorPane.add(chooseSize2, 1, 4);
		     	        errorPane.add(FSize, 0, 5);
		     	        errorPane.add(chooseSize3, 1, 5);
		     	        errorPane.add(TSize, 0, 6);
		     	        errorPane.add(chooseSize4, 1, 6);
		     	        errorPane.add(submitSizes, 0, 7);
		    		    Scene errorScene = new Scene(errorPane, 1200, 800);
			        	primaryStage.setScene(errorScene);
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
		        	}
	 
			    	else {
			    		Text rightMessage1 = new Text("Congratulations! You chose a right combination!");
			    		Text rightMessage2 = new Text("YOU ARE SOOO SMART!");
			    		Text rightMessage3 = new Text("Press submit: ");
			    		rightMessage1.setStyle("-fx-font: normal bold 25px 'serif' ");
			    		rightMessage2.setStyle("-fx-font: normal bold 25px 'serif' ");
			    		rightMessage3.setStyle("-fx-font: normal bold 25px 'serif' ");
			        	boardGame.setM(M);
			        	boardGame.setInitM(M);
			        	boardGame.setN(M);
			        	boardGame.setA(W_L/2);
			        	boardGame.setB(F_L/2);
			        	boardGame.setC(T_L/2);
			        	boardGame.setW(6);
			        	boardGame.setF(F);
			        	boardGame.setT(T);
			        	boardGame.weapons = new Weapon[6];
			        	boardGame.food = new Food[F];
			        	boardGame.traps = new Trap[T];
			        	
			        	for (int i = 0; i < 6; i++) {	// here we initialize the weapons-, food-, traps- boards
			    			boardGame.weapons[i] = new Weapon();
			    		}
			    		for (int i = 0; i < F; i++) {
			    			boardGame.food[i] = new Food();
			    		}
			    		for (int i = 0; i < T; i++) {
			    			boardGame.traps[i] = new Trap();
			    		}
			        	boardGame.createBoard();
			        	
			    		GridPane rightPane = createGridPane();
			    	    rightPane.add(rightMessage1, 0, 0);
			    	    rightPane.add(rightMessage2, 0, 1);
			    	    rightPane.add(rightMessage3, 0, 2);
			    	    rightPane.add(submitButton, 0, 4);
			    	    Scene rightScene = new Scene(rightPane, 1200, 800);
			        	primaryStage.setScene(rightScene);
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
			    	}
		        }
		    }));
		    
		    submitButton.setOnMouseClicked((new EventHandler<MouseEvent>() { 
		          public void handle(MouseEvent event) {  
				
					int startGame = 1;
					int W_L = chooseSize2.getValue();
		        	int F_L = chooseSize3.getValue();
		        	int T_L = chooseSize4.getValue();
		        	
		        	if (W_L >= F_L || F_L >= T_L) {
		        		Text errorMessage1 = new Text("The sizes you gave cannot create a board!");
		        		Text errorMessage2 = new Text("Choose an other combination of sizes: ");
		        		Text errorMessage3 = new Text("The sizes must be as below: ");
		        		Text errorMessage4 = new Text("Weapons-Board size < Food-Board size < Trap-Board size");
		        		errorMessage1.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage2.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage3.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		errorMessage4.setStyle("-fx-font: normal bold 20px 'serif' ");
		        		
		        		startGame = 0;
		        		
		        		//Creating a Grid Pane 
		        		
		        		chooseSize2.setValue(null);
		        		chooseSize3.setValue(null);
		        		chooseSize4.setValue(null);
		        		
		     	        GridPane errorPane = createGridPane(); 
		     	        errorPane.add(errorMessage1, 0, 0);
		     	        errorPane.add(errorMessage2, 0, 1);
		     	        errorPane.add(errorMessage3, 0, 2);
		     	        errorPane.add(errorMessage4, 1, 2);
		     	        errorPane.add(WSize, 0, 3);
		     	        errorPane.add(chooseSize2, 1, 3);
		     	        errorPane.add(FSize, 0, 4);
		     	        errorPane.add(chooseSize3, 1, 4);
		     	        errorPane.add(TSize, 0, 5);
		     	        errorPane.add(chooseSize4, 1, 5);
		     	        errorPane.add(submitSizes, 0, 6);
		    		    Scene errorScene = new Scene(errorPane, 1200, 800);
			        	primaryStage.setScene(errorScene);
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
		        	}
		        	else {
		        		int M = chooseSize1.getValue();
				    	int F = (int)scrollFood.getValue();
			        	int T = (int)scrollTraps.getValue();
			        	
			        	boardGame.setM(M);
			        	boardGame.setInitM(M);
			        	boardGame.setN(M);
			        	boardGame.setA(W_L/2);
			        	boardGame.setB(F_L/2);
			        	boardGame.setC(T_L/2);
			        	boardGame.setW(6);
			        	boardGame.setF(F);
			        	boardGame.setT(T);
			        	boardGame.weapons = new Weapon[6];
			        	boardGame.food = new Food[F];
			        	boardGame.traps = new Trap[T];
			        	
			        	for (int i = 0; i < 6; i++) {	// here we initialize the weapons-, food-, traps- boards
			    			boardGame.weapons[i] = new Weapon();
			    		}
			    		for (int i = 0; i < F; i++) {
			    			boardGame.food[i] = new Food();
			    		}
			    		for (int i = 0; i < T; i++) {
			    			boardGame.traps[i] = new Trap();
			    		}
			        	
			        	boardGame.createBoard();
			        	
		        	}
	 
		        	String name1 = null;
		        	String name2 = null;
		        	 
		        	if (maleRadio1.isSelected()){
		        		name1 = "Dipper Pines";
		        		Image male1 = new Image("male1.png");
			            charImg[0] = male1;
		        	}
		        	else if (femaleRadio1.isSelected()){
		        	    name1 = "Mabel Pines";
		        	    Image female1 = new Image("female1.png");
				        charImg[0] = female1;
		        	} 
		        	else if (neutralRadio1.isSelected()){
		        	    name1 = "Waddles";
		        	    Image other1 = new Image("other1.png");
				        charImg[0] = other1; 
		        	}
		        	    
		        	if (maleRadio2.isSelected()){
		        		name2 = "Soos"; 
		        		Image male2 = new Image("male2.png");
				        charImg[1] = male2;
			        }
			        else if (femaleRadio2.isSelected()){
			        	name2 = "Wendy Corduroy";
			        	Image female2 = new Image("female2.png");
				        charImg[1] = female2;
			        } 
			        else if (neutralRadio2.isSelected()){
			        	name2 = "Gnomes";
			        	Image other2 = new Image("other2.png");
				        charImg[1] = other2;
			        }
		        	
		        	if (player1choiceBox.getValue().toString() == "Heuristic") {
			        		p11.setBoard(boardGame);
			 	        	p11.setId(1);
			 	        	p11.setX(boardGame.getInitM()/2);
			 	        	p11.setY(-boardGame.getInitM()/2);
			 	        	p11.setScore(15);
			 	        	p11.setName(name1);
		        	}
		        	else if (player1choiceBox.getValue().toString() == "MinMax") {
			        		p111.setBoard(boardGame);
			 	        	p111.setId(1);
			 	        	p111.setX(boardGame.getInitM()/2);
			 	        	p111.setY(-boardGame.getInitM()/2);
			 	        	p111.setScore(15);
			 	        	p111.setName(name1); 
			        }
		        	else if (player1choiceBox.getValue().toString() == "Random") {
			        		p1.setBoard(boardGame);
			 	        	p1.setId(1);
			 	        	p1.setX(boardGame.getInitM()/2);
			 	        	p1.setY(-boardGame.getInitM()/2);
			 	        	p1.setScore(15);
			 	        	p1.setName(name1); 
			        }
		        	else if (player1choiceBox.getValue().toString() == "Manual") {
		        			p1111.setBoard(boardGame);
		        			p1111.setId(1);
		        			p1111.setX(boardGame.getInitM()/2);
		        			p1111.setY(-boardGame.getInitM()/2);
		        			p1111.setScore(15);
		        			if (nameText.getText() != null) {
		        				p1111.setName(nameText.getText());
		        			}
		        			else {
		        				p1111.setName(name1); 
		        			}
		        	}
		        	 
		        	if (player2choiceBox.getValue().toString() == "Heuristic") {
			        		p22.setBoard(boardGame);
			 	        	p22.setId(2);
			 	        	p22.setX(boardGame.getInitM()/2);
			 	        	p22.setY(boardGame.getInitM()/2);
			 	        	p22.setScore(15);
			 	        	p22.setName(name2);
		        	}
		        	else if (player2choiceBox.getValue().toString() == "MinMax") {
			        		p222.setBoard(boardGame);
			 	        	p222.setId(2);
			 	        	p222.setX(boardGame.getInitM()/2);
			 	        	p222.setY(boardGame.getInitM()/2);
			 	        	p222.setScore(15);
			 	        	p222.setName(name2); 
			        }
		        	else if (player2choiceBox.getValue().toString() == "Random") {
			        		p2.setBoard(boardGame);
			 	        	p2.setId(2);
			 	        	p2.setX(boardGame.getInitM()/2);
			 	        	p2.setY(boardGame.getInitM()/2);
			 	        	p2.setScore(15);
			 	        	p2.setName(name2);
			        }
		        	else if (player2choiceBox.getValue().toString() == "Manual") {
			        		p2222.setBoard(boardGame);
			 	        	p2222.setId(2);
			 	        	p2222.setX(boardGame.getInitM()/2);
			 	        	p2222.setY(boardGame.getInitM()/2);
			 	        	p2222.setScore(15);
			 	        	if (nameText.getText() != null) {
		        				p2222.setName(nameText.getText());
		        			}
		        			else {
		        				p2222.setName(name2); 
		        			}
		        	}
	
		        	//GridPane secondPane = createGridPane();
		        	ImageView poster = new ImageView(new Image("poster.png"));
					poster.setFitHeight(850);
					poster.setFitWidth(1200);
					poster.setPreserveRatio(true);
					GridPane secondPane = createGridPane();
					secondPane.setStyle("-fx-background-color: BLACK;");
					secondPane.add(poster, 0, 0);
	 
		        	if (p11.getId() != 0 && p22.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayHH, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	
		        	else if (p11.getId() != 0 && p2.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayHR, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1.getId() != 0 && p22.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayRH, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p111.getId() != 0 && p22.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayMH, 1, 0);
		        		Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p11.getId() != 0 && p222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayHM, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1.getId() != 0 && p2.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayRR, 1, 0);
		        		Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p111.getId() != 0 && p222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayMM, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p111.getId() != 0 && p2.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayMR, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1.getId() != 0 && p222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayRM, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1111.getId() != 0 && p2.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayPR, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1111.getId() != 0 && p22.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayPH, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1111.getId() != 0 && p222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayPM, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1.getId() != 0 && p2222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayRP, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p11.getId() != 0 && p2222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayHP, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p111.getId() != 0 && p2222.getId() != 0 && startGame == 1) {
		        		
		        		secondPane.add(buttonPlayMP, 1, 0);
		 	        	Scene secondScene = new Scene(secondPane, 1200, 800);
		 	        	primaryStage.setScene(secondScene);
			        	primaryStage.setFullScreen(true);
		 				primaryStage.show();
		        	}
		        	else if (p1111.getId() != 0 && p2222.getId() != 0 && startGame == 1){
		        		Text errorMessage1 = new Text("The players you chose can't play together!");
		        		Text errorMessage2 = new Text("Choose an other combination of players: ");
		        		Text errorMessage3 = new Text("The playable compinations are all apart from: ");
		        		Text errorMessage4 = new Text("Manual - Manual");
		        		errorMessage1.setStyle("-fx-font: normal bold 15px 'serif' ");
		        		errorMessage2.setStyle("-fx-font: normal bold 15px 'serif' ");
		        		errorMessage3.setStyle("-fx-font: normal bold 15px 'serif' ");
		        		errorMessage4.setStyle("-fx-font: normal bold 15px 'serif' ");
		        		
		        		//Creating a Grid Pane 
		        		player1choiceBox.setValue(null);
		        		player2choiceBox.setValue(null);
		     	        GridPane errorPane = createGridPane(); 
		     	        errorPane.add(errorMessage1, 0, 0);
		     	        errorPane.add(errorMessage2, 0, 1);
		     	        errorPane.add(errorMessage3, 0, 2);
		     	        errorPane.add(errorMessage4, 1, 2);
		     	        errorPane.add(player1Label, 0, 3);
		     	        errorPane.add(player2Label, 1, 3);
		     	        errorPane.add(player1choiceBox, 0, 4);
		     	        errorPane.add(player2choiceBox, 1, 4);
		     	        errorPane.add(buttonError, 0, 5);
		    		    Scene errorScene = new Scene(errorPane, 1200, 800);
			        	primaryStage.setScene(errorScene);
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
		        	}
		        }
			}));

		    //creating a board for the messages printed when game is over
			Text[] windowMessages = new Text[3];
			for (int i = 0; i < 3; i++) {
				windowMessages[i] = null;
			}
			
			//the type of our players
			Text player1 = new Text("Player 1: ");
		    Text player2 = new Text("Player 2: ");
		    
		    Button buttonClose = new Button("CLOSE");
	        buttonClose.setStyle("-fx-font: normal bold 15px 'serif' ");
		      
		    buttonClose.setOnMouseClicked((new EventHandler<MouseEvent>() { 
		          public void handle(MouseEvent event) { 
		             System.out.println("Ok, I will close the window."); 
		             primaryStage.close();
		          } 
		    }));
		    
			final int chooseCase = (int)((Math.random()*100) % 2);
			final Text[] statistics1 = new Text[2];
			final Text[] statistics2 = new Text[2];
			
			//when "up" button is clicked move the player up and check for the results of your move
			up.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(1);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0;
				
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
					    /*
					     * if the game is over, the windowMessages board is not empty
					     */
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						//else...
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(1);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0;
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			upRight.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(2);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0;
				
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(2);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0;
				
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			right.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(3);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(3);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			downRight.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(4);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    	
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(4);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			down.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(5);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(5);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    	
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			downLeft.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(6);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(6);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			left.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(7);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(7);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));
			
			upLeft.setOnMouseClicked((new EventHandler<MouseEvent>() {
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
					
					if (p1111.getId() != 0) {
						p1111.setDice(8);
						
						int p1First = 0;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
				    	if (p22.getId() != 0)
				    		characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
			    
				    	else if (p2.getId() != 0)
				    		characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
	
				    	else if (p222.getId() != 0)
				    		characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p1111, p22);
							if (p22.getId() != 0)
								boardGame.resizeBoard(p1111, p22);			    
					    	else if (p2.getId() != 0)
					    		boardGame.resizeBoard(p1111, p2);
					    	else if (p222.getId() != 0)
					    		boardGame.resizeBoard(p1111, p222);
						}///
						
						if (game.getRound() % 2 == p1First) {
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p22.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
							}
							else if (p2.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
							}
							else if (p222.getId() != 0) {
								movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p22.getId() != 0) {
								if (HeuristicPlayer.kill(p1111, p22, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p2.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p2, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p222.getId() != 0) {
					    		if (HeuristicPlayer.kill(p1111, p222, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p1First) {
							statistics1[0] = p1111.statistics()[0];
							statistics1[1] = p1111.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p2.getId() != 0) {
							p22.setName(p2.getName());
							p22.setScore(p2.getScore());
						}
						else if (p222.getId() != 0) {
							p22.setName(p222.getName());
							p22.setScore(p222.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p1111.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p22.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p22.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
											+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
							if (p1111.getScore() > p22.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p1111.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p1111.getScore() < p22.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p22.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
							Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p1111);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p1111, "pistol", pistol1);
					    	hasWeapon(p1111, "bow", bow1);
					    	hasWeapon(p1111, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p22.getId() != 0) {
					    		hasWeapon(p22, "pistol", pistol2);
						    	hasWeapon(p22, "bow", bow2);
						    	hasWeapon(p22, "sword", sword2);
					    	}
					    	else if (p2.getId() != 0) {
					    		hasWeapon(p2, "pistol", pistol2);
						    	hasWeapon(p2, "bow", bow2);
						    	hasWeapon(p2, "sword", sword2);
					    	}
					    	else if (p222.getId() != 0) {
					    		hasWeapon(p222, "pistol", pistol2);
						    	hasWeapon(p222, "bow", bow2);
						    	hasWeapon(p222, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p22.getId() != 0) {
								newPane.add(buttonPlayPH, 0, 1);
							}
							else if (p2.getId() != 0) {
								newPane.add(buttonPlayPR, 0, 1);
							}
							else if (p222.getId() != 0) {
								newPane.add(buttonPlayPM, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p1First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
					else if (p2222.getId() != 0) {
						p2222.setDice(8);
						
						int p1First = 1;
						int p2First = 1 - p1First;
					    
					    int moveP1X = 0, moveP1Y = 0; 
					    		
					    int [] movePlayer1 = new int[2];
					    
					    ImageView[] characters = new ImageView[2];
				    	characters[0] = putImage(charImg[0], p2222.getX(), p2222.getY(), boardGame);
				    	if (p11.getId() != 0)
				    		characters[1] = putImage(charImg[1], p11.getX(), p11.getY(), boardGame);
			    
				    	else if (p1.getId() != 0)
				    		characters[1] = putImage(charImg[1], p1.getX(), p1.getY(), boardGame);
	
				    	else if (p111.getId() != 0)
				    		characters[1] = putImage(charImg[1], p111.getX(), p111.getY(), boardGame);
	
						if (game.getRound() % 3 == 0) {
							boardGame.resizeBoard(p2222, p11);
							if (p11.getId() != 0)
								boardGame.resizeBoard(p2222, p11);			    
					    	else if (p1.getId() != 0)
					    		boardGame.resizeBoard(p2222, p1);
					    	else if (p111.getId() != 0)
					    		boardGame.resizeBoard(p2222, p111);
						}///
						
						if (game.getRound() % 2 == p2First) {
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
							
							if (p11.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p11, p2222.getDice());
							}
							else if (p1.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p1, p2222.getDice());
							}
							else if (p111.getId() != 0) {
								movePlayer1 = p2222.moveItGood(p111, p2222.getDice());
							}
	
							moveP1X = movePlayer1[0];
							moveP1Y = movePlayer1[1];	
							characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
							
							movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
														+ "\ty = " + movePlayer1[1]);
							movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
				
							
							if (p11.getId() != 0) {
								if (HeuristicPlayer.kill(p2222, p11, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
							}
					    	else if (p1.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p1, 2)) {
									player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
					    	else if (p111.getId() != 0) {
					    		if (HeuristicPlayer.kill(p2222, p111, 2)) {
									player1kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT AND WINS!!");
									player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
									windowMessages[0] = player1kills;
									System.out.println("I finished!");
								}///
					    	}
						}
						
						if (game.getRound() % 2 == p2First) {
							statistics1[0] = p2222.statistics()[0];
							statistics1[1] = p2222.statistics()[1];
						}
						else {
							System.out.println("ERROR 404");
						}
						
					    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
				
						
						if (p1.getId() != 0) {
							p11.setName(p1.getName());
							p11.setScore(p1.getScore());
						}
						else if (p111.getId() != 0) {
							p11.setName(p111.getName());
							p11.setScore(p111.getScore());
						}
						
						if (game.round > 500) {						// when the game lasts too long, it stops.
							gamePaused = new Text("GAME PAUSED");
							windowMessages[0] = gamePaused;
							System.out.println("I finished!");
						}///
				
						if (p2222.getScore() < 0) {
							scoreWin2 = new Text("Player P2 " + p11.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin2;
							System.out.println("I finished!");
						}///
						if (p11.getScore() < 0) {
							scoreWin1 = new Text("Player P1 " + p2222.getName() + " wins the game! \nThe other player has a negative score!");
							windowMessages[0] = scoreWin1;
							System.out.println("I finished!");
						}///
						
						
					    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
							Endgame = new Text("!GAME IS OVER!");
							scores = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore()
											+ " \nThe score of P2 " + p11.getName() + " is: " + p11.getScore());
							if (p2222.getScore() > p11.getScore()) {
								InfinityWar1 = new Text("Player P1 " + p2222.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar1;
							}
							
							else if (p2222.getScore() < p11.getScore()) {
								InfinityWar2 = new Text("Player P2 " + p11.getName() + " wins the game!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = InfinityWar2;
							}
							else {
								draw = new Text("We have a draw!!");
								windowMessages[0] = Endgame;
								windowMessages[1] = scores;
								windowMessages[2] = draw;
							}
					    }	
	    
						if (windowMessages[0] != null) {
					    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
				        	primaryStage.setFullScreen(true);
							primaryStage.show();
					    }
						else {
					    	Text score1 = new Text("The score of P1 " + p2222.getName() + " is: " + p2222.getScore());
							Text score2 = new Text("The score of P2 " + p11.getName() + " is: " + p11.getScore());
							score1.setStyle("-fx-font: normal bold 15px 'serif' ");
							score2.setStyle("-fx-font: normal bold 15px 'serif' ");
							Group newBoard = createBoardHuman(boardGame, p2222);
							newBoard.getChildren().add(characters[0]);
							newBoard.getChildren().add(characters[1]);
		
							Group p1stats = new Group();
					    	p1stats.getChildren().add(player1);
					    	score1.setY(25);
					    	p1stats.getChildren().add(score1);
					    	movement1.setY(50);
					    	p1stats.getChildren().add(movement1);
					    	
					    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
					    	pis1 = setImage(pis1);
					    	pis1.setX(0);
					    	pis1.setY(80);
					    	ImageView s1 = new ImageView(new Image("sword1.png"));
					    	s1 = setImage(s1);
					    	s1.setX(150);
					    	s1.setY(75);
					    	ImageView b1 = new ImageView(new Image("bow1.png"));
					    	b1 = setImage(b1);
					    	b1.setX(75);
					    	b1.setY(75);
					    	Rectangle pistol1 = new Rectangle();
					    	pistol1.setHeight(60);
					    	pistol1.setWidth(60);
					    	pistol1.setX(0);
					    	pistol1.setY(75);
					    	pistol1.setFill(Color.TOMATO);
					    	Rectangle bow1 = new Rectangle();
					    	bow1.setHeight(60);
					    	bow1.setWidth(60);
					    	bow1.setX(75);
					    	bow1.setY(75);
					    	bow1.setFill(Color.TOMATO);
					    	Rectangle sword1 = new Rectangle();
					    	sword1.setHeight(60);
					    	sword1.setWidth(60);
					    	sword1.setY(75);
					    	sword1.setX(150);
					    	sword1.setFill(Color.TOMATO);
					    	
					    	hasWeapon(p2222, "pistol", pistol1);
					    	hasWeapon(p2222, "bow", bow1);
					    	hasWeapon(p2222, "sword", sword1);
					    	
					    	p1stats.getChildren().add(pistol1);
					    	p1stats.getChildren().add(bow1);
					    	p1stats.getChildren().add(sword1);
					    	p1stats.getChildren().add(pis1);
					    	p1stats.getChildren().add(s1);
					    	p1stats.getChildren().add(b1);
	
					    	Group p2stats = new Group();
					    	p2stats.getChildren().add(player2);
					    	score2.setY(25);
					    	p2stats.getChildren().add(score2);
					    	movement2.setY(50);
					    	p2stats.getChildren().add(movement2);
					    	
					    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
					    	pis2 = setImage(pis2);
					    	pis2.setX(0);
					    	pis2.setY(80);
					    	ImageView s2 = new ImageView(new Image("sword2.png"));
					    	s2 = setImage(s2);
					    	s2.setX(150);
					    	s2.setY(75);
					    	ImageView b2 = new ImageView(new Image("bow2.png"));
					    	b2 = setImage(b2);
					    	b2.setX(75);
					    	b2.setY(75);
					    	Rectangle pistol2 = new Rectangle();
					    	pistol2.setHeight(60);
					    	pistol2.setWidth(60);
					    	pistol2.setX(0);
					    	pistol2.setY(75);
					    	pistol2.setFill(Color.TOMATO);
					    	Rectangle bow2 = new Rectangle();
					    	bow2.setHeight(60);
					    	bow2.setWidth(60);
					    	bow2.setX(75);
					    	bow2.setY(75);
					    	bow2.setFill(Color.TOMATO);
					    	Rectangle sword2 = new Rectangle();
					    	sword2.setHeight(60);
					    	sword2.setWidth(60);
					    	sword2.setY(75);
					    	sword2.setX(150);
					    	sword2.setFill(Color.TOMATO);
					    	if (p11.getId() != 0) {
					    		hasWeapon(p11, "pistol", pistol2);
						    	hasWeapon(p11, "bow", bow2);
						    	hasWeapon(p11, "sword", sword2);
					    	}
					    	else if (p1.getId() != 0) {
					    		hasWeapon(p1, "pistol", pistol2);
						    	hasWeapon(p1, "bow", bow2);
						    	hasWeapon(p1, "sword", sword2);
					    	}
					    	else if (p111.getId() != 0) {
					    		hasWeapon(p111, "pistol", pistol2);
						    	hasWeapon(p111, "bow", bow2);
						    	hasWeapon(p111, "sword", sword2);
					    	}
					    	
					    	
					    	p2stats.getChildren().add(pistol2);
					    	p2stats.getChildren().add(bow2);
					    	p2stats.getChildren().add(sword2);
					    	p2stats.getChildren().add(pis2);
					    	p2stats.getChildren().add(s2);
					    	p2stats.getChildren().add(b2);
	
							GridPane newPane = createGridPane();
							newPane.add(newBoard, 1, 2);
							if (p11.getId() != 0) {
								newPane.add(buttonPlayHP, 0, 1);
							}
							else if (p1.getId() != 0) {
								newPane.add(buttonPlayRP, 0, 1);
							}
							else if (p111.getId() != 0) {
								newPane.add(buttonPlayMP, 0, 1);
							}
							newPane.add(buttonTerminate, 2, 1);
							Group boards = new Group();
							ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
							foodpoints.setFitHeight(100);
							foodpoints.setPreserveRatio(true);
							ImageView wt = new ImageView(new Image("encounters.png"));
							wt.setFitHeight(100);
							wt.setPreserveRatio(true);
							wt.setX(230);
							wt.setSmooth(true);
							boards.getChildren().add(foodpoints);
							boards.getChildren().add(wt);
	
							newPane.add(p1stats, 0, 2);
							newPane.add(p2stats, 2, 2);
							newPane.add(boards, 1, 3);
	
							if (game.getRound() % 2 == p2First) {
								if (statistics1[1] == null) {
									newPane.add(statistics1[0], 1, 5);
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
								else if (statistics1[1] != null) {
									newPane.add(statistics1[0], 0, 5);
									newPane.add(statistics1[1], 2, 5);
									statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
									statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								}
							}
							
							Scene newScene = new Scene(newPane, 1200, 800);
							game.setRound(++game.round);
							primaryStage.setScene(newScene);
				        	primaryStage.setMaximized(true);
							primaryStage.show();
						}
					}
				}
			}));

			//case 1
			buttonPlayHH.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p11.getX(), p11.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p11, p22);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p11, p22, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p11.moveIt(p22);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p11, p22, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p22, p11, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p22.moveIt(p11);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p22, p11, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p11.statistics()[0];
						statistics1[1] = p11.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p22.statistics()[0];
						statistics2[1] = p22.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p11.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p22.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p22.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p11.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore()
										+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
						if (p11.getScore() > p22.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p11.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p11.getScore() < p22.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p22.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore());
						Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p11, "pistol", pistol1);
				    	hasWeapon(p11, "bow", bow1);
				    	hasWeapon(p11, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p22, "pistol", pistol2);
				    	hasWeapon(p22, "bow", bow2);
				    	hasWeapon(p22, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayHH, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 2
			buttonPlayHR.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p11.getX(), p11.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p11, p2);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p11, p2, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p11.moveIt(p2);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p11, p2, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2, p11, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2.move();	//**********************
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2, p11, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p11.statistics()[0];
						statistics1[1] = p11.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p11.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p11.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore()
										+ " \nThe score of P2 " + p2.getName() + " is: " + p2.getScore());
						if (p11.getScore() > p2.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p11.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p11.getScore() < p2.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore());	//*************
						Text score2 = new Text("The score of P2 " + p2.getName() + " is: " + p2.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p11, "pistol", pistol1);	//**********************************
				    	hasWeapon(p11, "bow", bow1);
				    	hasWeapon(p11, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2, "pistol", pistol2);	//*********************
				    	hasWeapon(p2, "bow", bow2);
				    	hasWeapon(p2, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayHR, 0, 1);	//************************
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
				}
			}));
			
			//case 3
			buttonPlayRH.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1.getX(), p1.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1, p22);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1, p22, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1.move();
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1, p22, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p22, p1, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p22.moveIt(p1);	//**********************
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p22, p1, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p22.statistics()[0];
						statistics2[1] = p22.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p22.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p22.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore()
										+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
						if (p1.getScore() > p22.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1.getScore() < p22.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p22.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore());	//*************
						Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1, "pistol", pistol1);	//**********************************
				    	hasWeapon(p1, "bow", bow1);
				    	hasWeapon(p1, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p22, "pistol", pistol2);	//*********************
				    	hasWeapon(p22, "bow", bow2);
				    	hasWeapon(p22, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayRH, 0, 1);	//************************
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
				}
			}));
			
			//case 4
			buttonPlayMH.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p111.getX(), p111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p111, p22);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p111, p22, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p111.getNextMove(p111.getX(), p111.getY(), p22, null, null);
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p111, p22, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p22, p111, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p22.moveIt(p111);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p22, p111, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p111.statistics()[0];
						statistics1[1] = p111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p22.statistics()[0];
						statistics2[1] = p22.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p22.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p22.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore()
										+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
						if (p111.getScore() > p22.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p111.getScore() < p22.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p22.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore());
						Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p111, "pistol", pistol1);
				    	hasWeapon(p111, "bow", bow1);
				    	hasWeapon(p111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p22, "pistol", pistol2);
				    	hasWeapon(p22, "bow", bow2);
				    	hasWeapon(p22, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayMH, 0, 1);	
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 5
			buttonPlayHM.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p11.getX(), p11.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p11, p222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p11, p222, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p11.moveIt(p222);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p11, p222, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p222, p11, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p222.getNextMove(p222.getX(), p222.getY(), p11, null, null);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p222, p11, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p11.statistics()[0];
						statistics1[1] = p11.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p222.statistics()[0];
						statistics2[1] = p222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p11.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p11.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore()
										+ " \nThe score of P2 " + p222.getName() + " is: " + p222.getScore());
						if (p11.getScore() > p222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p11.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p11.getScore() < p222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore());
						Text score2 = new Text("The score of P2 " + p222.getName() + " is: " + p222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p11, "pistol", pistol1);
				    	hasWeapon(p11, "bow", bow1);
				    	hasWeapon(p11, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p222, "pistol", pistol2);
				    	hasWeapon(p222, "bow", bow2);
				    	hasWeapon(p222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayHM, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 6
			buttonPlayRR.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1.getX(), p1.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1, p2);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1, p2, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1.move();
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1, p2, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2, p1, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2.move();
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2, p1, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						
					}
					else if (game.getRound() % 2 == p2First) {
						
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore()
										+ " \nThe score of P2 " + p2.getName() + " is: " + p2.getScore());
						if (p1.getScore() > p2.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1.getScore() < p2.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore());
						Text score2 = new Text("The score of P2 " + p2.getName() + " is: " + p2.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1, "pistol", pistol1);
				    	hasWeapon(p1, "bow", bow1);
				    	hasWeapon(p1, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2, "pistol", pistol2);
				    	hasWeapon(p2, "bow", bow2);
				    	hasWeapon(p2, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayRR, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							
						}
						else if(game.getRound() % 2 == p2First) {
							
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 7
			buttonPlayMM.setOnMouseClicked((new EventHandler<MouseEvent>(){
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p111.getX(), p111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p111, p222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p111, p222, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p111.getNextMove(p111.getX(), p111.getY(), null, null, p222);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p111, p222, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p222, p111, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p222.getNextMove(p222.getX(), p222.getY(), null, null, p111);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p222, p111, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p111.statistics()[0];
						statistics1[1] = p111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p222.statistics()[0];
						statistics2[1] = p222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore()
										+ " \nThe score of P2 " + p222.getName() + " is: " + p222.getScore());
						if (p111.getScore() > p222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p111.getScore() < p222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore());
						Text score2 = new Text("The score of P2 " + p222.getName() + " is: " + p222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p111, "pistol", pistol1);
				    	hasWeapon(p111, "bow", bow1);
				    	hasWeapon(p111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p222, "pistol", pistol2);
				    	hasWeapon(p222, "bow", bow2);
				    	hasWeapon(p222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayMM, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 8
			buttonPlayMR.setOnMouseClicked((new EventHandler<MouseEvent>(){
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p111.getX(), p111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p111, p2);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p111, p2, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p111.getNextMove(p111.getX(), p111.getY(), null, p2, null);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p111, p2, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2, p111, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2.move();
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2, p111, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p111.statistics()[0];
						statistics1[1] = p111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore()
										+ " \nThe score of P2 " + p2.getName() + " is: " + p2.getScore());
						if (p111.getScore() > p2.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p111.getScore() < p2.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore());
						Text score2 = new Text("The score of P2 " + p2.getName() + " is: " + p2.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p111, "pistol", pistol1);
				    	hasWeapon(p111, "bow", bow1);
				    	hasWeapon(p111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2, "pistol", pistol2);
				    	hasWeapon(p2, "bow", bow2);
				    	hasWeapon(p2, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayMR, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 9
			buttonPlayRM.setOnMouseClicked((new EventHandler<MouseEvent>(){
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = setTurns(chooseCase);
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
			
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1.getX(), p1.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1, p222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1, p222, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1.move();
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1, p222, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p222, p1, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p222.getNextMove(p222.getX(), p222.getY(), null, p1, null);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p222, p1, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p222.statistics()[0];
						statistics2[1] = p222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore()
										+ " \nThe score of P2 " + p222.getName() + " is: " + p222.getScore());
						if (p1.getScore() > p222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1.getScore() < p222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore());
						Text score2 = new Text("The score of P2 " + p222.getName() + " is: " + p222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoard(boardGame);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1, "pistol", pistol1);
				    	hasWeapon(p1, "bow", bow1);
				    	hasWeapon(p1, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p222, "pistol", pistol2);
				    	hasWeapon(p222, "bow", bow2);
				    	hasWeapon(p222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonPlayMM, 0, 1);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 10
			buttonPlayPH.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 0;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p1111.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p22.getX(), p22.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1111, p22);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1111, p22, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1111.moveItGood(p22, p1111.getDice());
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1111, p22, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p22, p1111, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p22.moveIt(p1111);
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p22, p1111, 2)) {
							player2kills = new Text("Player " + p22.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p1111.statistics()[0];
						statistics1[1] = p1111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p22.statistics()[0];
						statistics2[1] = p22.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p22.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p22.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
										+ " \nThe score of P2 " + p22.getName() + " is: " + p22.getScore());
						if (p1111.getScore() > p22.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1111.getScore() < p22.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p22.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
						Text score2 = new Text("The score of P2 " + p22.getName() + " is: " + p22.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p1111);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1111, "pistol", pistol1);
				    	hasWeapon(p1111, "bow", bow1);
				    	hasWeapon(p1111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p22, "pistol", pistol2);
				    	hasWeapon(p22, "bow", bow2);
				    	hasWeapon(p22, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						if (game.getRound() % 2 == p2First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p1111), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 11
			buttonPlayPM.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 0;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p1111.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p222.getX(), p222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1111, p222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1111, p222, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1111.moveItGood(p222, p1111.getDice());
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1111, p222, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p222, p1111, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p222.getNextMove(p222.getX(), p222.getY(), null, p1111, null);
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p222, p1111, 2)) {
							player2kills = new Text("Player " + p222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p1111.statistics()[0];
						statistics1[1] = p1111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p222.statistics()[0];
						statistics2[1] = p222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
										+ " \nThe score of P2 " + p222.getName() + " is: " + p222.getScore());
						if (p1111.getScore() > p222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1111.getScore() < p222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
						Text score2 = new Text("The score of P2 " + p222.getName() + " is: " + p222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p1111);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1111, "pistol", pistol1);
				    	hasWeapon(p1111, "bow", bow1);
				    	hasWeapon(p1111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p222, "pistol", pistol2);
				    	hasWeapon(p222, "bow", bow2);
				    	hasWeapon(p222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						if (game.getRound() % 2 == p2First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p1111), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 12
			buttonPlayPR.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 0;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p1111.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1111.getX(), p1111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2.getX(), p2.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1111, p2);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1111, p2, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1111.moveItGood(p2, p1111.getDice());
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1111, p2, 2)) {
							player1kills = new Text("Player " + p1111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2, p1111, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2.move();
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p22, p1111, 2)) {
							player2kills = new Text("Player " + p2.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p1111.statistics()[0];
						statistics1[1] = p1111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore()
										+ " \nThe score of P2 " + p2.getName() + " is: " + p2.getScore());
						if (p1111.getScore() > p2.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1111.getScore() < p2.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1111.getName() + " is: " + p1111.getScore());
						Text score2 = new Text("The score of P2 " + p2.getName() + " is: " + p2.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p1111);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1111, "pistol", pistol1);
				    	hasWeapon(p1111, "bow", bow1);
				    	hasWeapon(p1111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2, "pistol", pistol2);
				    	hasWeapon(p2, "bow", bow2);
				    	hasWeapon(p2, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							
						}
						if (game.getRound() % 2 == p2First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p1111), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 13
			buttonPlayHP.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 1;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p2222.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p11.getX(), p11.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2222.getX(), p2222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p11, p2222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p11, p2222, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p11.moveIt(p2222);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p11, p2222, 2)) {
							player1kills = new Text("Player " + p11.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2222, p11, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2222.moveItGood(p11, p2222.getDice());
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2222, p11, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p11.statistics()[0];
						statistics1[1] = p11.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p2222.statistics()[0];
						statistics2[1] = p2222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p11.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p11.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore()
										+ " \nThe score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						if (p11.getScore() > p2222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p11.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p11.getScore() < p2222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p11.getName() + " is: " + p11.getScore());
						Text score2 = new Text("The score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p2222);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p11, "pistol", pistol1);
				    	hasWeapon(p11, "bow", bow1);
				    	hasWeapon(p11, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2222, "pistol", pistol2);
				    	hasWeapon(p2222, "bow", bow2);
				    	hasWeapon(p2222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						if (game.getRound() % 2 == p1First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p2222), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 14
			buttonPlayMP.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 1;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p2222.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p111.getX(), p111.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2222.getX(), p2222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p111, p2222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p111, p2222, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p111.getNextMove(p111.getX(), p111.getY(), null, p2222, null);
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p111, p2222, 2)) {
							player1kills = new Text("Player " + p111.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2222, p111, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2222.moveItGood(p111, p2222.getDice());
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2222, p111, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						statistics1[0] = p111.statistics()[0];
						statistics1[1] = p111.statistics()[1];
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p2222.statistics()[0];
						statistics2[1] = p2222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p111.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p111.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore()
										+ " \nThe score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						if (p111.getScore() > p2222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p111.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p111.getScore() < p2222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p111.getName() + " is: " + p111.getScore());
						Text score2 = new Text("The score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p2222);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p111, "pistol", pistol1);
				    	hasWeapon(p111, "bow", bow1);
				    	hasWeapon(p111, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2222, "pistol", pistol2);
				    	hasWeapon(p2222, "bow", bow2);
				    	hasWeapon(p2222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							if (statistics1[1] == null) {
								newPane.add(statistics1[0], 1, 5);
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics1[1] != null) {
								newPane.add(statistics1[0], 0, 5);
								newPane.add(statistics1[1], 2, 5);
								statistics1[1].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics1[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						if (game.getRound() % 2 == p1First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p2222), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
			//case 15
			buttonPlayRP.setOnMouseClicked((new EventHandler<MouseEvent>() { 
				public void handle(MouseEvent event) {
					Text movement1 = new Text();
					Text movement2 = new Text();
					Text player1kills = new Text();
					Text player2kills = new Text();
					Text gamePaused = new Text();
					Text scoreWin1 = new Text();
					Text scoreWin2 = new Text();
					Text draw = new Text();
					Text Endgame = new Text();
					Text scores = new Text();
					Text InfinityWar1 = new Text();
					Text InfinityWar2 = new Text();
			
					movement1.setStyle("-fx-font: normal bold 15px 'serif' ");
					movement2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2kills.setStyle("-fx-font: normal bold 15px 'serif' ");
					gamePaused.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin1.setStyle("-fx-font: normal bold 15px 'serif' ");
					scoreWin2.setStyle("-fx-font: normal bold 15px 'serif' ");
					draw.setStyle("-fx-font: normal bold 15px 'serif' ");
					Endgame.setStyle("-fx-font: normal bold 15px 'serif' ");
					scores.setStyle("-fx-font: normal bold 15px 'serif' ");
					InfinityWar1.setStyle("-fx-font: normal bold 15px 'serif' ");					
					InfinityWar2.setStyle("-fx-font: normal bold 15px 'serif' ");
					player1.setStyle("-fx-font: normal bold 15px 'serif' ");
					player2.setStyle("-fx-font: normal bold 15px 'serif' ");
	
				    int p1First = 1;
				    int p2First = 1 - p1First;
				    				    
				    int moveP1X = 0, moveP1Y = 0, 
				    		moveP2X = 0, moveP2Y = 0; // used in the GetStringRepresentation() for the position of the players. 
				    									//We need them global, because they change in each round.
				    p2222.setDice(2);
				    
				    int [] movePlayer1 = new int[2];
				    int [] movePlayer2 = new int[2];
				    
				    ImageView[] characters = new ImageView[2];
			    	characters[0] = putImage(charImg[0], p1.getX(), p1.getY(), boardGame);
			    	characters[1] = putImage(charImg[1], p2222.getX(), p2222.getY(), boardGame);
		    
					if (game.getRound() % 3 == 0) {
						boardGame.resizeBoard(p1, p2222);
					}///
					
					if (game.getRound() % 2 == p1First) {
						
						if (HeuristicPlayer.kill(p1, p2222, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
						
						movePlayer1 = p1.move();
						
						
						moveP1X = movePlayer1[0];
						moveP1Y = movePlayer1[1];	
						characters[0] = putImage(charImg[0], moveP1X, moveP1Y, boardGame);
						
						movement1 = new Text("The player P1 goes to position: \nx = " + movePlayer1[0] 
													+ "\ty = " + movePlayer1[1]);			
						
						if (HeuristicPlayer.kill(p1, p2222, 2)) {
							player1kills = new Text("Player " + p1.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player1kills;
							System.out.println("I finished!");
						}///
					}
					else if (game.getRound() % 2 == p2First) {
						
						if (HeuristicPlayer.kill(p2222, p1, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
						
						movePlayer2 = p2222.moveItGood(p1, p2222.getDice());
						
						
						moveP2X = movePlayer2[0];
						moveP2Y = movePlayer2[1];
						characters[1] = putImage(charImg[1], moveP2X, moveP2Y, boardGame);
						
						movement2 = new Text("The player P2 goes to position: \nx = " + movePlayer2[0] 
													+ "\ty = " + movePlayer2[1]);
			
						
						if (HeuristicPlayer.kill(p2222, p1, 2)) {
							player2kills = new Text("Player " + p2222.getName() + "\nKILLS THE OPPONENT \nAND WINS!!");
							windowMessages[0] = player2kills;
							System.out.println("I finished!");
						}///
					}
			
					if (game.getRound() % 2 == p1First) {
						
					}
					else if (game.getRound() % 2 == p2First) {
						statistics2[0] = p2222.statistics()[0];
						statistics2[1] = p2222.statistics()[1];
					}
					else {
						System.out.println("ERROR 404");
					}
					
				    //boardGame.getStringRepresentation(moveP1X, moveP1Y, moveP2X, moveP2Y);
			
					if (game.round > 500) {						// when the game lasts too long, it stops.
						gamePaused = new Text("GAME PAUSED");
						windowMessages[0] = gamePaused;
						System.out.println("I finished!");
					}///
			
					if (p1.getScore() < 0) {
						scoreWin2 = new Text("Player P2 " + p2222.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin2;
						System.out.println("I finished!");
					}///
					if (p2222.getScore() < 0) {
						scoreWin1 = new Text("Player P1 " + p1.getName() + " wins! \nThe other player \nhas a negative score!");
						windowMessages[0] = scoreWin1;
						System.out.println("I finished!");
					}///
					
					
				    if(boardGame.getN()/2 <= boardGame.getA() && boardGame.getM()/2 <= boardGame.getA()) {
						Endgame = new Text("**GAME IS OVER**");
						scores = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore()
										+ " \nThe score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						if (p1.getScore() > p2222.getScore()) {
							InfinityWar1 = new Text("\nPlayer P1 " + p1.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar1;
						}
						
						else if (p1.getScore() < p2222.getScore()) {
							InfinityWar2 = new Text("\nPlayer P2 " + p2222.getName() + " wins!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = InfinityWar2;
						}
						else {
							draw = new Text("We have a draw!!");
							windowMessages[0] = Endgame;
							windowMessages[1] = scores;
							windowMessages[2] = draw;
						}
				    }	
    
					if (windowMessages[0] != null) {
				    	primaryStage.setScene(windowLastMessage(windowMessages, buttonClose));
			        	primaryStage.setFullScreen(true);
						primaryStage.show();
				    }
					else {
				    	Text score1 = new Text("The score of P1 " + p1.getName() + " is: " + p1.getScore());
						Text score2 = new Text("The score of P2 " + p2222.getName() + " is: " + p2222.getScore());
						score1.setStyle("-fx-font: normal bold 15px 'serif' ");
						score2.setStyle("-fx-font: normal bold 15px 'serif' ");
						Group newBoard = createBoardHuman(boardGame, p2222);
						newBoard.getChildren().add(characters[0]);
						newBoard.getChildren().add(characters[1]);
	
						Group p1stats = new Group();
				    	p1stats.getChildren().add(player1);
				    	score1.setY(25);
				    	p1stats.getChildren().add(score1);
				    	movement1.setY(50);
				    	p1stats.getChildren().add(movement1);
				    	
				    	ImageView pis1 = new ImageView(new Image("pistol1.png"));
				    	pis1 = setImage(pis1);
				    	pis1.setX(0);
				    	pis1.setY(80);
				    	ImageView s1 = new ImageView(new Image("sword1.png"));
				    	s1 = setImage(s1);
				    	s1.setX(150);
				    	s1.setY(75);
				    	ImageView b1 = new ImageView(new Image("bow1.png"));
				    	b1 = setImage(b1);
				    	b1.setX(75);
				    	b1.setY(75);
				    	Rectangle pistol1 = new Rectangle();
				    	pistol1.setHeight(60);
				    	pistol1.setWidth(60);
				    	pistol1.setX(0);
				    	pistol1.setY(75);
				    	pistol1.setFill(Color.TOMATO);
				    	Rectangle bow1 = new Rectangle();
				    	bow1.setHeight(60);
				    	bow1.setWidth(60);
				    	bow1.setX(75);
				    	bow1.setY(75);
				    	bow1.setFill(Color.TOMATO);
				    	Rectangle sword1 = new Rectangle();
				    	sword1.setHeight(60);
				    	sword1.setWidth(60);
				    	sword1.setY(75);
				    	sword1.setX(150);
				    	sword1.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p1, "pistol", pistol1);
				    	hasWeapon(p1, "bow", bow1);
				    	hasWeapon(p1, "sword", sword1);
				    	
				    	p1stats.getChildren().add(pistol1);
				    	p1stats.getChildren().add(bow1);
				    	p1stats.getChildren().add(sword1);
				    	p1stats.getChildren().add(pis1);
				    	p1stats.getChildren().add(s1);
				    	p1stats.getChildren().add(b1);

				    	Group p2stats = new Group();
				    	p2stats.getChildren().add(player2);
				    	score2.setY(25);
				    	p2stats.getChildren().add(score2);
				    	movement2.setY(50);
				    	p2stats.getChildren().add(movement2);
				    	
				    	ImageView pis2 = new ImageView(new Image("pistol2.png"));
				    	pis2 = setImage(pis2);
				    	pis2.setX(0);
				    	pis2.setY(80);
				    	ImageView s2 = new ImageView(new Image("sword2.png"));
				    	s2 = setImage(s2);
				    	s2.setX(150);
				    	s2.setY(75);
				    	ImageView b2 = new ImageView(new Image("bow2.png"));
				    	b2 = setImage(b2);
				    	b2.setX(75);
				    	b2.setY(75);
				    	Rectangle pistol2 = new Rectangle();
				    	pistol2.setHeight(60);
				    	pistol2.setWidth(60);
				    	pistol2.setX(0);
				    	pistol2.setY(75);
				    	pistol2.setFill(Color.TOMATO);
				    	Rectangle bow2 = new Rectangle();
				    	bow2.setHeight(60);
				    	bow2.setWidth(60);
				    	bow2.setX(75);
				    	bow2.setY(75);
				    	bow2.setFill(Color.TOMATO);
				    	Rectangle sword2 = new Rectangle();
				    	sword2.setHeight(60);
				    	sword2.setWidth(60);
				    	sword2.setY(75);
				    	sword2.setX(150);
				    	sword2.setFill(Color.TOMATO);
				    	
				    	hasWeapon(p2222, "pistol", pistol2);
				    	hasWeapon(p2222, "bow", bow2);
				    	hasWeapon(p2222, "sword", sword2);
				    	
				    	p2stats.getChildren().add(pistol2);
				    	p2stats.getChildren().add(bow2);
				    	p2stats.getChildren().add(sword2);
				    	p2stats.getChildren().add(pis2);
				    	p2stats.getChildren().add(s2);
				    	p2stats.getChildren().add(b2);

						GridPane newPane = createGridPane();
						newPane.add(newBoard, 1, 2);
						newPane.add(buttonTerminate, 2, 1);
						Group boards = new Group();
						ImageView foodpoints = new ImageView(new Image("foodpoints.png"));
						foodpoints.setFitHeight(100);
						foodpoints.setPreserveRatio(true);
						ImageView wt = new ImageView(new Image("encounters.png"));
						wt.setFitHeight(100);
						wt.setPreserveRatio(true);
						wt.setX(230);
						wt.setSmooth(true);
						boards.getChildren().add(foodpoints);
						boards.getChildren().add(wt);

						newPane.add(p1stats, 0, 2);
						newPane.add(p2stats, 2, 2);
						newPane.add(boards, 1, 3);

						if (game.getRound() % 2 == p1First) {
							
						}
						else if(game.getRound() % 2 == p2First) {
							if (statistics2[1] == null) {
								newPane.add(statistics2[0], 1, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
							else if (statistics2[1] != null) {
								newPane.add(statistics2[0], 0, 5);
								newPane.add(statistics2[1], 2, 5);
								statistics2[0].setStyle("-fx-font: normal bold 15px 'serif' ");
								statistics2[1].setStyle("-fx-font: normal bold 15px 'serif' ");
							}
						}
						if (game.getRound() % 2 == p1First) {
							Text diceLabel = new Text("Choose your next move: ");
							diceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");

							newPane.add(diceLabel, 0, 4);
							newPane.add(createButtonGroup(up, upRight, right, downRight, down, downLeft, left, upLeft, boardGame, p2222), 0, 3);
							
							//newPane.add(chooseDice, 2, 6);
						}
	
						Scene newScene = new Scene(newPane, 1200, 800);
						game.setRound(++game.round);
						primaryStage.setScene(newScene);
			        	primaryStage.setMaximized(true);
						primaryStage.show();
					}
			    }
			}));
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	  
	public static void main(String[] args) {
				
		launch(args);

	}
}
