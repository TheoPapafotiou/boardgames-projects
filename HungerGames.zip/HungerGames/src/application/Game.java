/*
 * PAPAFOTIOU THEODOROS - AEM: 9708 - PHONE: 6977021300 - EMAIL: papafotit@ece.auth.gr
 * 
 * TATLI DIMITRA - AEM: 9802 - PHONE: 6971881071 - EMAIL: dimitatl@ece.auth.gr
 * 
 */

package application;

public class Game {
	
	int round;		// counter that counts the rounds of the game

	public Game() {					// 1st constructor with no arguments
		round = 1;
	}
	public Game(Game game) {		// 2nd constructor with an object of class Game as an argument
		game.round = round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public int getRound() {
		return round;
	}
}
