/*
 * PAPAFOTIOU THEODOROS - AEM: 9708 - PHONE: 6977021300 - EMAIL: papafotit@ece.auth.gr
 * 
 * TATLI DIMITRA - AEM: 9802 - PHONE: 6971881071 - EMAIL: dimitatl@ece.auth.gr
 * 
 */

package application;

import java.util.ArrayList;

import javafx.scene.text.Text;

public class ManualPlayer extends Player{
	/*
	 * path[0] = dice
	 * path[1] = points
	 * path[2] = if weapon
	 * path[3] = if food
	 * path[4] = if trap
	 * path[5] = roundPlayer
	 */
	ArrayList<Integer[][]> path = new ArrayList<>();	//created to put in it the information above
	int r;				//shows "how far" the player can see
	int roundPlayer;	//a counter of the rounds (we use it in our functions)
	int dice;
	
	public ManualPlayer() {		// 1st constructor with no arguments (variables just like the class PLayer)
		id = 0;
		roundPlayer = 0;
		name = null;
		score = 0;
		x = 0;
		y = 0;
		bow = null;
		pistol = null;
		sword = null;
		r = 3;
		roundPlayer = 0;
		dice = 0;
	}
	
	public ManualPlayer (int id, String name, int x, int y, Board board, int r) {	// 2nd constructor with specific arguments
		this.id = id;
		this.x = x;
		this.y = y;
		this.name = name;
		this.board = board;
		this.r = r;
		roundPlayer = 0;
		dice = 0;
	}
	
	public ManualPlayer (ManualPlayer p) {		// 3rd constructor with an object of class HeuristicPlayer as an argument
		id = p.id;
		board = p.board;
		name = p.name;
		score = p.score;
		x = p.x;
		y = p.y;
		bow = p.bow;
		pistol = p.pistol;
		sword = p.sword;
		r = p.r;
		roundPlayer = p.roundPlayer;
		dice = p.dice;
	}
	

	public void setR(int r) {
		this.r = r;
	}
	public int getR() {
		return r;
	}
	public void setRoundPlayer(int roundPlayer) {
		this.roundPlayer = roundPlayer;
	}
	public int getRoundPlayer() {
		return roundPlayer;
	}
	public void setDice(int dice) {
		this.dice = dice;
	}
	public int getDice() {
		return dice;
	}
	
	public static void wait(int ms){				// we created a function that can be used for delays in the code: wait() 
        try
        {
            Thread.sleep(ms);
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }
    }
	
	/*
	 *	It returns the distance from the object we want (player, weapon, food, trap) 
	 *
	 *  Since we calculate the Cartesian distance, the distance = [1,2) is the field r = 1 around the player,
	 *  the distance = [2, 3) is the field r = 2 around the player etc
	 */
	public float distanceFrom(int xx, int yy) {
		
		int m, n, s, t;
		
		if(x*xx > 0 && y*yy > 0) {		// if player and object are on the same quadrant
			m = x;
			n = xx;
			s = y;
			t = yy;
		}
		else if(x*xx > 0 && y*yy < 0) {	// if player and object are on the quadrant 1 - 2, 3 - 4 relatively (and vice versa)	
			m = x;
			n = xx;
			if (y < 0) {
				s = y + 1;
				t = yy;
			}
			else {
				s = y;
				t = yy + 1;
			}
		}
		else if(x*xx < 0 && y*yy > 0) {	// if player and object are on the quadrant 1 - 4, 2 - 3 relatively (and vice versa)
		    s = y;
			t = yy;
			if (x < 0) {
				m = x + 1;
				n = xx;
			}
			else {
				m = x;
				n = xx + 1;
			}
		}	
		else {							// if player and object are on the quadrant 1 - 3, 2 - 4 relatively (and vice versa)
			if (x < 0) {
				m = x + 1;
				n = xx;
			}
			else {
				m = x;
				n = xx + 1;
			}
			
			if (y < 0) {
				s = y + 1;
				t = yy;
			}
			else {
				s = y;
				t = yy + 1;
			}
		}
			
		float distance = (float)Math.sqrt(Math.pow(m - n, 2) + Math.pow(s - t, 2));
		
		for (int i = 1; i <= getR(); i++) {
			if (distance >= i && distance < (i + 1)) {
				distance = i;
			}
		}
	
		if (distance < (getR() + 1)) 
			return distance;
		
		else 
			return -1;
	}
	
	/*
	 * It indicates in which direction is the object we want to find (player, weapon, food, trap) 
	 */
	public int direction(int xx, int yy) {
		if (x == xx && y != yy) {
			if (y > yy)
				return 7;
			else 
				return 3;
		}
		else if (x != xx && y == yy) {
			if(x > xx)
				return 1;
			else
				return 5;
		}
		else {
			if (x > xx && y > yy)
				return 8;
			else if (x > xx && y < yy)
				return 2;
			else if (x < xx && y > yy)
				return 6;
			else
				return 4;
		}
	}
	
	/*
	 * It indicates if the dice (taken as an input) leads to an allowed move 
	 * It returns true if the move is allowed, false if not
	 */
	public boolean isAllowed(int k) {
				
		int M = board.getM();
		int N = board.getN();
			
			if (y == -N/2 && x != M/2 && x != -M/2) {			//if in left side, NO corners
				if (k < 6) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (y == N/2 && x != M/2 && x != -M/2) {		//if in right side, NO corners
				if (k == 1 || k > 4) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y != N/2 && y != -N/2) {		//if in down side, NO corners
				if (k < 4 || k > 6) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y != N/2 && y != -N/2) {		//if in up side, NO corners
				if (k > 2 && k < 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y == N/2) {					//if in up right corner
				if (k > 4 && k < 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y == N/2) {					//if in down right corner
				if (k == 1 || k == 7 || k == 8) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == M/2 && y == -N/2) {					//if in down left corner
				if (k < 4) {
					return true;
				}
				else {
					return false;
				}
			}
			else if (x == -M/2 && y == -N/2) {					//if in up left corner
				if (k == 3 || k == 4 || k == 5) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
	}
	
	/*
	 * It returns a board with information about the distance of a weapon from a player
	 * (-1 if distance > r), about the direction of that weapon (if distance > r, direction = 0)
	 * and informs us if the weapon is a pistol or not
	 * P.S. All that weapons are the ones that the player can take (getPlayerId() == id)
	 */
	public float [][] weaponDistance() {
		
		float[][] weaponInfo = new float[board.getW()][3];
		
		for (int i = 0; i < board.getW(); i++) {										
			int xx = board.weapons[i].getX();
			int yy = board.weapons[i].getY();
			
			int direction = 0;
			int pistol = 0;
			if (board.weapons[i].getType() == "pistol")
				pistol = 1;
			
			float weaponDistance = distanceFrom(xx, yy);
			if(weaponDistance != -1)
				direction = direction(xx, yy);
			
			if (board.weapons[i].getPlayerId() != id)
				weaponDistance = 0;
			
			weaponInfo[i][0] = weaponDistance;
			weaponInfo[i][1] = direction;
			weaponInfo[i][2] = pistol;
		}
		
		return weaponInfo;
	}
	
	/*
	 * It returns a board with information about the distance of a food from a player
	 * (-1 if distance > r), about the direction of that food (if distance > r, direction = 0)
	 * and about the points which that food gives.
	 */
	public float [][] foodDistance() {
		
		float[][] foodInfo = new float[board.getF()][3];
		
		for (int i = 0; i < board.getF(); i++) {										
			int xx = board.food[i].getX();
			int yy = board.food[i].getY();
			
			int direction = 0;

			float foodDistance = distanceFrom(xx, yy);
			if(foodDistance != -1)
				direction = direction(xx, yy);
			
			
			foodInfo[i][0] = foodDistance;
			foodInfo[i][1] = direction;
			foodInfo[i][2] = board.food[i].getPoints();
		}
		
		return foodInfo;
	}
	
	/*
	 * It returns a board with information about the distance of a trap from a player
	 * (-1 if distance > r), about the direction of that trap (if distance > r, direction = 0)
	 * and about the points which that trap "takes".
	 */
	public float [][] trapDistance() {
		
		float[][] trapInfo = new float[board.getT()][3];
		
		for (int i = 0; i < board.getT(); i++) {										
			int xx = board.traps[i].getX();
			int yy = board.traps[i].getY();
			
			int direction = direction(xx, yy);

			float trapDistance = distanceFrom(xx, yy);
			
			trapInfo[i][0] = trapDistance;
			trapInfo[i][1] = direction;
			trapInfo[i][2] = board.traps[i].getPoints();
		}
		
		return trapInfo;
	}
	
	/*
	 * It indicates if the dice (taken as an input) leads to an allowed move 
	 * It returns true if the move is allowed, false if not
	 */
	/*
	 * It returns a board with the coordinates (x, y) of the new position of the player (it "moves" the player)
 	 * The dice is chosen by the human_player. We check firstly if the move that the dice indicates is IN the borders of the board.
	 * Before we return the the coordinates, we put the results of that move in the ArrayList<> (the dice chosen, the points it took,
	 * if it took a weapon, if it took food, if it went on a trap)
	 */
	public int[] moveItGood(Player p, int dice){
		
		//Scanner input = new Scanner(System.in);
		int x_x = 0;
		int y_y = 0;
		int bestDice = 0;
		float [][] weaponInfo = weaponDistance();
		float [][] foodInfo = foodDistance();
		float [][] trapInfo = trapDistance();
 		
		while(true) {
			
			System.out.println("\t 1 -> up\n"
						+ "\t 2 -> up right\n"
						+ "\t 3 -> right\n"
						+ "\t 4 -> down right\n"
						+ "\t 5 -> down\n"
						+ "\t 6 -> down left\n"
						+ "\t 7 -> left\n"
						+ "\t 8 -> up left\n");
			
			System.out.println("The weapons nearby (distance < r) are: ");
			
			for (int i = 0; i < board.getW(); i++) {
				if (weaponInfo[i][0] > 0) {
					System.out.print("\t At distance: " + weaponInfo[i][0] + " and at direction: " + weaponInfo[i][1]);
				}
				else {
					continue;
				}
				if (weaponInfo[i][2] == 1) {
					System.out.print(" and it is a pistol");
				}
				System.out.println();
			}
			
			System.out.println("The food nearby (distance < r) is: ");
			
			for (int i = 0; i < board.getF(); i++) {
				if (foodInfo[i][0] != -1) {
					System.out.println("\t At distance: " + foodInfo[i][0] + " at direction: " + foodInfo[i][1] + " with points: " + foodInfo[i][2]);
				}
			}
			
			System.out.println("The traps nearby (distance < r) are: ");
			
			for (int i = 0; i < board.getT(); i++) {
				if (trapInfo[i][0] != -1) {
					System.out.println("\t At distance: " + trapInfo[i][0] + " at direction: " + trapInfo[i][1] + " with penalty: " + trapInfo[i][2]);
				}
			}
			
			System.out.print("Give me the dice for your new position: \n\t DICE = "); 
			//wait(5000);
			bestDice = dice;
			
			/*
			if(input.hasNextInt())
			     bestDice = input.nextInt(); // if there is another number  
			else 
			     bestDice = input.nextInt(); // nothing added in the input 
			*/
			
			if (bestDice == 1) {
				x_x = this.x - 1;
				y_y = this.y;
			}
			else if (bestDice == 2) {
				x_x = this.x - 1;
				y_y = this.y + 1;
			}
			else if (bestDice == 3) {
				x_x = this.x;
				y_y = this.y + 1;
			}
			else if (bestDice == 4) {
				x_x = this.x + 1;
				y_y = this.y + 1;
			}
			else if (bestDice == 5) {
				x_x = this.x + 1;
				y_y = this.y;
			}
			else if (bestDice == 6) {
				x_x = this.x + 1;
				y_y = this.y - 1;
			}
			else if (bestDice == 7) {
				x_x = this.x;
				y_y = this.y - 1;
			}
			else if (bestDice == 8){
				x_x = this.x - 1;
				y_y = this.y - 1;
			}
			else {
				System.out.println("You are out of bounds, what an idiot, you lost.");
				continue;
			}
			
			if (isAllowed(bestDice)) {
				setX(x_x);
				setY(y_y);
				break;
			}
			else {
				System.out.println("You are out of bounds, what an idiot, you lost.");
				continue;
			}
		}
		
		int Movement [] = {getX(), getY()};
		
		int [][] results = moveResult(Movement[0], Movement[1]);
		
		Integer[][] data = new Integer[6][2];
		
		data[0][0] = bestDice;			//dice
		data[0][1] = 0;					
		data[1][0] = results[0][0];		//points	
		data[1][1] = 0;
		data[2][0] = results[1][0];		//weapon or not
		data[2][1] = results[1][1];		//where on weapons[]
		data[3][0] = results[2][0];		//food or not
		data[3][1] = results[2][1];		//where on food[]
		data[4][0] = results[3][0];		//trap or not
		data[4][1] = results[3][1];		//where on traps[]
		data[5][0] = roundPlayer;		//roundPlayer
		data[5][1] = 0;
		
		path.add(roundPlayer, data);
		
		setRoundPlayer(++roundPlayer);
		
		return Movement;
	}
	
	/*
	 * It prints on the terminal the "results" of each move using the ArrayList.
	 * (the dice chosen, if the player gained Points, or took a weapon, or lost Points)
	 */
	public Text[] statistics() {
		
		int j = path.get(roundPlayer - 1)[2][1];
		int t = path.get(roundPlayer - 1)[4][1];
		int points = path.get(roundPlayer - 1)[1][0];
		String[] texts = new String[2];
		Text[] textResult = new Text[2];
 		texts[1] = null;
 		textResult[1] = null;
		
		String chooseDice = "Player " + name + " chose the " + path.get(roundPlayer - 1)[0][0] + " dice!";
		System.out.println(chooseDice);
		texts[0] = chooseDice;
		textResult[0] = new Text(chooseDice);
		
		if (path.get(roundPlayer - 1)[2][0] == 1) {
			String foundWeapon = "Congrats, you found a WEAPON! It is a " + board.weapons[j].getType();
			System.out.println(foundWeapon);
			texts[1] = foundWeapon;
			textResult[1] = new Text(foundWeapon);
		}
		if (path.get(roundPlayer - 1)[3][0] == 1) {
			String foundFood = "Congrats, you found food! + " + points + " points gained!";
			System.out.println(foundFood);
			texts[1] = foundFood;
			textResult[1] = new Text(foundFood);
		}
		if (path.get(roundPlayer - 1)[4][0] == 1) {
			if((board.traps[t].getType() == "rope" && sword != null) || (board.traps[t].getType() == "animal" && bow != null)) {
				String foundTrap0 = "You fell into a TRAP, but you escaped it! NO points lost";
				texts[1] = foundTrap0;
				textResult[1] = new Text(foundTrap0);
			}
			else {
				String foundTrap1 = "Ooops, you fell into a TRAP! " + points + " points lost!";
				texts[1] = foundTrap1;
				textResult[1] = new Text(foundTrap1);
			}
		}
		return textResult;
	}
}
