#include "player_random.h"
//#include "player_manual.h"
#include "player_9708_9626.h"

Ships (*player_1_setup_ships)(int) = &setupShips_9708_9626;
Place (*player_1_hit)(Board *, char *, Place) = &hit_9708_9626;
void  (*player_1_move_ship)(int, int *, int *, Board *, Ships *) = &moveShip_9708_9626;
void  (*reset_vars_player1)() = &reset_variables_9708_9626;

//Ships (*player_2_setup_ships)(int) = &setupShips_manual;
//Place (*player_2_hit)(Board *, char *, Place) = &hit_manual;
//void  (*player_2_move_ship)(int, int *, int *, Board *, Ships *) = &moveShip_manual;
//void  (*reset_vars_player2)() = &reset_variables_manual;

Ships (*player_2_setup_ships)(int) = &setupShips_random;
Place (*player_2_hit)(Board *, char *, Place) = &hit_random;
void  (*player_2_move_ship)(int, int *, int *, Board *, Ships *) = &moveShip_random;
void  (*reset_vars_player2)() = &reset_variables_random;



void allocateBoard(Board *b){
  int i;
  b->board = (Place **)malloc(b->width * sizeof(Place *));
  for(i = 0 ; i < b->width ; i++)
    b->board[i] = (Place *)malloc(b->height * sizeof(Place));
}

// Initializes board with character 0
void initializeBoard(Board *b){
  int i, j;
  for(i = 0 ; i < b->width ; i++)
    for(j = 0 ; j < b->height ; j++){
      b->board[i][j].symbol = EMPTY_SYMBOL;
      b->board[i][j].x = i;
      b->board[i][j].y = j;
    }
}

void printBoard(Board *p, int player, Ships *s){
  int i, j;
  for(i = 0 ; i < 18 ; i++) putchar('-');
  printf("Player %d", player);
  for(i = 0 ; i < 17 ; i++) putchar('-');
  printf("\tSHIPS\n");
  for(i = 0 ; i < p->width ; i++){
    putchar('a' + i);
    putchar('|');
    for(j = 0 ; j < p->height ; j++){
      if(p->board[i][j].symbol == SHIP_SYMBOL){
        if(player == 1) printf(BCYN "%c " RESET, p->board[i][j].symbol);
        else printf(BGRN "%c " RESET, p->board[i][j].symbol);
      }
      else if(p->board[i][j].symbol == HIT_SYMBOL)
        printf(BRED "%c " RESET, p->board[i][j].symbol);
      else
        printf(WHT "%c " RESET, p->board[i][j].symbol);
    }
    printf("|");
    // Print the ships here
    if(i < s->shipsNumber){
      printf("\tSize %d: ", s->ships[i].length);
      for(j = 0 ; j < s->ships[i].length ; j++){
        if(s->ships[i].hits[j] == 0) printf(BWHT "%c" RESET, SHIP_SYMBOL);
        else printf(BRED "%c" RESET, SHIP_SYMBOL);
      }
    }
    printf("\n");
  }
  for(i = 0 ; i < 2 ; i++) putchar('-');
  for(i = 0 ; i < p->width ; i++){
      putchar('a' + i);
      putchar(' ');
  }
  for(i = 0 ; i < 1 ; i++) putchar('-');
  printf("\n\n");
}

void updateBoardShipsInit(Board *p, Ships *s){
  int k;
  // Uncomment for testing reasons
  // for(k = 0 ; k < s->shipsNumber ; k++) printShip(&s->ships[k]);

  int i, j;
  for(i = 0 ; i < p->width ; i++){
    for(j = 0 ; j < p->height ; j++){
      // Search all ships to update the symbols
      for(k = 0 ; k < s->shipsNumber ; k++){
        //check if ship is horizontal
        if((s->ships[k].start.x == s->ships[k].end.x) && s->ships[k].end.x == i){
          if(s->ships[k].start.y <= j && j <= s->ships[k].end.y){
            p->board[i][j].symbol = SHIP_SYMBOL;
          }
        }
        else if((s->ships[k].start.y == s->ships[k].end.y) && s->ships[k].end.y == j){ // its vertical
          if(s->ships[k].start.x <= i && i <= s->ships[k].end.x){
            p->board[i][j].symbol = SHIP_SYMBOL;
          }
        }
      }
    }
  }
}

int main(void){
  /* Initialises random number generator */
  time_t t;
  srand((unsigned) time(&t));
  int i;
  int player1_victories = 0;
  int player2_victories = 0;
  int moves_made = 0;
  int player1_hits = 0;
  int player2_hits = 0;
  int player1_hits_av = 0;
  int player2_hits_av = 0;


  for(i = 1; i <= GAMES_TO_RUN; ++i) {
    printf("\nGame #%d... ", i);
    // Check for draws
    if(player1_victories + player2_victories >= GAMES_TO_RUN)
      break;

    Board b1;
    b1.width = b1.height = BOARD_SIZE;
    Board b2;
    b2.width = b2.height = BOARD_SIZE;
    Board p1_perception;
    p1_perception.width = p1_perception.height = BOARD_SIZE;
    Board p2_perception;
    p2_perception.width = p2_perception.height = BOARD_SIZE;

    //The last given point by the student is stored in savePlace_student
    Place savePlace_p1;
    //initialize
    savePlace_p1.symbol = EMPTY_SYMBOL;
    savePlace_p1.x = -1;
    savePlace_p1.y = -1;

    //The last given point by the random is stored in savePlace_student
    Place savePlace_p2;
    //initialize
    savePlace_p2.symbol = EMPTY_SYMBOL;
    savePlace_p2.x = -1;
    savePlace_p2.y = -1;

    allocateBoard(&b1);
    allocateBoard(&b2);
    allocateBoard(&p1_perception);
    allocateBoard(&p2_perception);

    initializeBoard(&b1);
    initializeBoard(&b2);
    initializeBoard(&p1_perception);
    initializeBoard(&p2_perception);

    // Ships initializations by players
    Ships p1_ships = (*player_1_setup_ships)(BOARD_SIZE);
    Ships p2_ships = (*player_2_setup_ships)(BOARD_SIZE);

    // Ships checks!
    char player_1_ships_ok = checkInitialShipsSelection(&p1_ships, 1);
    if (player_1_ships_ok == 0) {
      printf(RED "Player 1 disqualified! Player 2 takes the game!\n");
      player2_victories++;
      continue;
    }
    char player_2_ships_ok = checkInitialShipsSelection(&p2_ships, 2);
    if (player_2_ships_ok == 0) {
      printf(RED "Player 2 disqualified! Player 1 takes the game!\n");
      player1_victories++;
      continue;
    }

    // Update the boards symbols with ships
    updateBoardShipsInit(&b1, &p1_ships);
    updateBoardShipsInit(&b2, &p2_ships);

    printf("\n");

    char deadShips[] = {0, 0, 0, 0, 0, 0, 0};
    moves_made = 0;
    int player1_motions = 0;
    int player2_motions = 0;
    while (1) {
      moves_made++;
      // printf("%d\n", moves_made);

      if(moves_made >= MAX_MOVES){
        player1_victories++;
        player2_victories++;
        printf(YEL "Its a draw...\n " RESET);
        break;
      }

      // Player 1 play
      prepareDeadShipsTable(&p2_ships, deadShips);
      if(GAMES_TO_RUN == 1)
        printf("Player 1 plays...\n");
      Place p1sel = (*player_1_hit)(&p1_perception, deadShips, savePlace_p1);

      if (p1sel.x < 0 || p1sel.x >= BOARD_SIZE || p1sel.y < 0 || p1sel.y >= BOARD_SIZE) {
        printf(RED "Player 1 selected an out-of-the-bounds move. Player 2 wins!\n" RESET);
        player2_victories++;
        break;
      }
      //Should test if p1_perception is untouched by the player... BUT if he/she
      // changes it he messes up with his/her perception so... :P

      if (checkShipHit(&b2, p1sel)) {
        b2.board[p1sel.x][p1sel.y].symbol = HIT_SYMBOL;
        p1_perception.board[p1sel.x][p1sel.y].symbol = HIT_SYMBOL;
        p1sel.symbol = HIT_SYMBOL; // Needed in order to pass the symbol in savePlace_student
        updateHitShip(p1sel, &p2_ships);
        player1_hits++;
      } else {
        b2.board[p1sel.x][p1sel.y].symbol = MISS_SYMBOL;
        p1_perception.board[p1sel.x][p1sel.y].symbol = MISS_SYMBOL;
        p1sel.symbol = MISS_SYMBOL; // Needed in order to pass the symbol in savePlace_student
      }

      savePlace_p1 = p1sel;
      // if(GAMES_TO_RUN == 1){
      //   printBoard(&b1, 1, &p1_ships);
      //   printBoard(&b2, 2, &p2_ships);
      // }
      if (checkEndGame(&p2_ships) != 0) {
        printf(GRN "Player 1 has won!\n" RESET);
        player1_victories++;
        break;
      }

      // Player 2 play
      prepareDeadShipsTable(&p1_ships, deadShips);
      if(GAMES_TO_RUN == 1)
        printf("Player 2 plays...\n");
      Place p2sel = (*player_2_hit)(&p2_perception, deadShips, savePlace_p2);

      if (p2sel.x < 0 || p2sel.x >= BOARD_SIZE || p2sel.y < 0 || p2sel.y >= BOARD_SIZE) {
        printf(RED "Player 2 selected an out-of-the-bounds move. Player 1 wins!\n" RESET);
        player1_victories++;
        break;
      }

      //Should test if p1_perception is untouched by the player... BUT if he/she
      // changes it he messes up with his/her perception so... :P

      if (checkShipHit(&b1, p2sel)) {
        b1.board[p2sel.x][p2sel.y].symbol = HIT_SYMBOL;
        p2_perception.board[p2sel.x][p2sel.y].symbol = HIT_SYMBOL;
        p2sel.symbol = HIT_SYMBOL; // Needed in order to pass the symbol in savePlace_random
        updateHitShip(p2sel, &p1_ships);
        player2_hits++;
      } else {
        //printf("we ve got a miss\n");
        b1.board[p2sel.x][p2sel.y].symbol = MISS_SYMBOL;
        p2_perception.board[p2sel.x][p2sel.y].symbol = MISS_SYMBOL;
        p2sel.symbol = MISS_SYMBOL; // Needed in order to pass the symbol in savePlace_random
      }

      savePlace_p2 = p2sel;
      if(GAMES_TO_RUN == 1){
        printBoard(&b1, 1, &p1_ships);
        printBoard(&b2, 2, &p2_ships);
      }
      if (checkEndGame(&p1_ships) != 0) {
        printf(GRN "Player 2 has won!\n" RESET);
        player2_victories++;
        break;
      }

      // Just for debug
      //printf("Last hit of player 1: [%d, %d, %c]\n", savePlace_p1.x, savePlace_p1.y, savePlace_p1.symbol);
      //printf("Last hit of player 2: [%d, %d, %c]\n", savePlace_p2.x, savePlace_p2.y, savePlace_p2.symbol);

      // Can Player 1 move ship? If yes call the function
      char motion;
      motion = canPlayerMoveShip(&p1_ships);
      //printf("Player 1 moves? %d\n", motion);
      if (motion != 0 && player1_motions < MAX_MOTIONS) {
        int shipToMove = -1;
        int motionCommand = 0;
        (*player_1_move_ship)(motion, &shipToMove, &motionCommand, &b1, &p1_ships);
        if(GAMES_TO_RUN == 1)
          printf("Player 1 decided to move: %d by %d\n", shipToMove + 1, motionCommand);
        if (motionCommand != 0) {
          player1_motions++;
          // printf("pl 1 motions: %d\n", player1_motions);
          int code = implementShipMotion(&b1, &p1_ships, shipToMove, motionCommand, motion);
          if (code == -1) {
            printf("Player 2 wins!\n");
            player2_victories++;
            break;
          }
        }
      }

      // Can Player 2 move ship? If yes call the function
      motion = canPlayerMoveShip(&p2_ships);
      //printf("Player 2 moves? %d\n", motion);
      if (motion != 0 && player2_motions < MAX_MOTIONS) {
        // printf("pl 2 motions: %d\n", player1_motions);
        int shipToMove = -1;
        int motionCommand = 0;
        (*player_2_move_ship)(motion, &shipToMove, &motionCommand, &b2, &p2_ships);
        if(GAMES_TO_RUN == 1)
          printf("Player 2 decided to move ship %d by %d\n", shipToMove + 1, motionCommand);
        if (motionCommand != 0) {
          player2_motions++;
          int code = implementShipMotion(&b2, &p2_ships, shipToMove, motionCommand, motion);
          if (code == -1) {
            printf("Player 1 wins!\n");
            player1_victories++;
            break;
          }
        }
      }
      if(GAMES_TO_RUN == 1) usleep(100000);
    }
    //TODO calculate game values
    player1_hits_av += player1_hits;
    player2_hits_av += player2_hits;

    //TODO reset all values
    player1_hits = 0;
    player2_hits = 0;

    //TODO free allocated memory
    int m;
    for (m = 0; m < b1.width; ++m) {
      free(b1.board[m]);
      free(b2.board[m]);
      free(p1_perception.board[m]);
      free(p2_perception.board[m]);
    }

    free(b1.board);
    free(b2.board);
    free(p1_perception.board);
    free(p2_perception.board);

    for (m = 0; m < 7; ++m) {
      free(p1_ships.ships[m].hits);
      free(p2_ships.ships[m].hits);
    }

    free(p1_ships.ships);
    free(p2_ships.ships);

    //TODO call players' reset functions
    (*reset_vars_player1)();
    (*reset_vars_player2)();

    // printf("\n\n\n");

  }

  //TODO calculate game values
  player1_hits_av = player1_hits_av / GAMES_TO_RUN;
  player2_hits_av = player2_hits_av / GAMES_TO_RUN;

  player1_victories = player1_victories * 100 / GAMES_TO_RUN;
  player2_victories = player2_victories * 100 / GAMES_TO_RUN;

  //TODO print stats
  printf("\nPlayer 1 stats: \n");
  printf("Wins percentage in %d games played: %d %%\n", GAMES_TO_RUN, player1_victories);
  printf("Average successful hits in %d games played: %d\n", GAMES_TO_RUN, player1_hits_av);

  printf("\nPlayer 2 stats: \n");
  printf("Wins percentage in %d games played: %d %%\n", GAMES_TO_RUN, player2_victories);
  printf("Average successful hits in %d games played: %d\n", GAMES_TO_RUN, player2_hits_av);

  //TODO decide winner
  if(player1_victories > player2_victories){
    printf("PLAYER 1 WINS with a better win percentage!!\n");

  }else if(player1_victories < player2_victories){
    printf("PLAYER 2 WINS with a better win percentage!!\n");

  }else{
    if(player1_hits_av < player2_hits_av){
      printf("Player 1 and player 2 have equal win percentages but PLAYER 1 WINS because of better hits percentage\n");
    }else{
      printf("Player 1 and player 2 have equal win percentages but PLAYER 2 WINS because of better hits percentage\n");
    }
  }
  return 0;
}
