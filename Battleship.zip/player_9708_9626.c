#include "player_9708_9626.h"
/* We declare:
- 1 ship of size 2
- 2 ships of size 3
- 2 ships of size 5
- 1 ship of size 7
- 1 ship of size 9 */
extern Ships setupShips_9708_9626(int boardSize) {
  Ships s;
  s.ships = (Ship *)malloc(7 * sizeof(Ship));
  s.shipsNumber = 7;
  int i, k = 0;
  int choose_position = 0;          ///in order to choose the position of our ships (3 cases)

  choose_position = rand() % 3;     ///Q1

  if (choose_position == 0){

      /// Declare Ship 1 of size 2
      s.ships[k].length = 2;
      s.ships[k].start.x = 6;
      s.ships[k].start.y = 4;
      s.ships[k].end.x = 6;
      s.ships[k].end.y = 5;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 8;
      s.ships[k].start.y = 4;
      s.ships[k].end.x = 10;
      s.ships[k].end.y = 4;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 0;
      s.ships[k].start.y = 9;
      s.ships[k].end.x = 0;
      s.ships[k].end.y = 11;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 9;
      s.ships[k].start.y = 18;
      s.ships[k].end.x = 13;
      s.ships[k].end.y = 18;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 16;
      s.ships[k].start.y = 11;
      s.ships[k].end.x = 16;
      s.ships[k].end.y = 15;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 7
      s.ships[k].length = 7;
      s.ships[k].start.x = 1;
      s.ships[k].start.y = 8;
      s.ships[k].end.x = 7;
      s.ships[k].end.y = 8;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 9
      s.ships[k].length = 9;
      s.ships[k].start.x = 18;
      s.ships[k].start.y = 11;
      s.ships[k].end.x = 18;
      s.ships[k].end.y = 19;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

  }

  if (choose_position == 1){

      /// Declare Ship 1 of size 2
      s.ships[k].length = 2;
      s.ships[k].start.x = 5;
      s.ships[k].start.y = 15;
      s.ships[k].end.x = 6;
      s.ships[k].end.y = 15;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 2;
      s.ships[k].start.y = 1;
      s.ships[k].end.x = 4;
      s.ships[k].end.y = 1;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 16;
      s.ships[k].start.y = 4;
      s.ships[k].end.x = 18;
      s.ships[k].end.y = 4;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 13;
      s.ships[k].start.y = 8;
      s.ships[k].end.x = 13;
      s.ships[k].end.y = 12;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 14;
      s.ships[k].start.y = 6;
      s.ships[k].end.x = 18;
      s.ships[k].end.y = 6;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 7
      s.ships[k].length = 7;
      s.ships[k].start.x = 19;
      s.ships[k].start.y = 1;
      s.ships[k].end.x = 19;
      s.ships[k].end.y = 7;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 9
      s.ships[k].length = 9;
      s.ships[k].start.x = 6;
      s.ships[k].start.y = 19;
      s.ships[k].end.x = 14;
      s.ships[k].end.y = 19;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;
  }

  if (choose_position == 2){

      /// Declare Ship 1 of size 2
      s.ships[k].length = 2;
      s.ships[k].start.x = 14;
      s.ships[k].start.y = 8;
      s.ships[k].end.x = 15;
      s.ships[k].end.y = 8;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 19;
      s.ships[k].start.y = 1;
      s.ships[k].end.x = 19;
      s.ships[k].end.y = 3;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 3
      s.ships[k].length = 3;
      s.ships[k].start.x = 9;
      s.ships[k].start.y = 13;
      s.ships[k].end.x = 11;
      s.ships[k].end.y = 13;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 5;
      s.ships[k].start.y = 17;
      s.ships[k].end.x = 9;
      s.ships[k].end.y = 17;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 2 of size 5
      s.ships[k].length = 5;
      s.ships[k].start.x = 15;
      s.ships[k].start.y = 0;
      s.ships[k].end.x = 19;
      s.ships[k].end.y = 0;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 7
      s.ships[k].length = 7;
      s.ships[k].start.x = 8;
      s.ships[k].start.y = 1;
      s.ships[k].end.x = 8;
      s.ships[k].end.y = 7;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;

      /// Declare Ship 1 of size 9
      s.ships[k].length = 9;
      s.ships[k].start.x = 0;
      s.ships[k].start.y = 8;
      s.ships[k].end.x = 0;
      s.ships[k].end.y = 16;
      s.ships[k].hits = (char *)malloc(s.ships[k].length);
      for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
      k++;
  }

  return s;
}

    ///our global variables so we can access them both in the hits_function and in the reset_varaibles_function
    static int i = 0;                               /// to fill the hitsBoard
    static int k = 0;                               /// to fill the last_Board
    static int m = 0;                               /// to fill the all_hits
    static int z = 0;                               /// to fill the special_board
    static int N = 0;                               /// to determine the size of the opponent's last ship
    static int w = 0;                               /// activated when we know the direction of the last ship (which we didn't know before)
    static int q = 0;                               /// activated when the prelast ship has at least 2 random hits (it helps us manage the last_board[] without writing 100 more lines of code)
    static int j = 0;                               /// activated when we understand that the last 2 ships were considered as one and during the change of the last_board records
    static int tries = 0;                           /// our tries in each game
    static int in_while = 0;                        /// it indicates when we are in the while_mode (when hitting around the first hit around each ship)
    static int random1 = 1;                         /// activated when we are in random_mode during the hits of the first 6 ships
    static int vertical = 1;                        /// 1, 2, 3 if the ship is vertical, 0 if it is not
    static int horizontal = 1;                      /// 1, 2, 3 if the ship is horizontal, 0 if it is not
    static int around = 1;                          /// to search around the first hit in each of the first 6 ships
    static int counter = 0;                         /// it passes from 'while' to 'while' when we hit around the first hit on each ship from the first 5. It also indicates whether the ship is vertical(1, 2) or horizontal (3.4).
    static Place hits_board [40];                   /// a board where we put specific hits (usually the first ones on each ship)
    static int round1 = 0;                          /// we use round1 and round2 in order to continue our hits in a ship after going upwards or leftwards respectivelly
    static int round2 = 0;
    static int dont_do_if = 1;                      /// (it is commented in the function)
    static int round_last = 0;                      /// to go from the first hit to the second hit, when we are in mode_fucking the last ship after knowing its direction
    static int another_counter = 0;                 /// it passes from 'while' to 'while' when we hit around the first hit on each ship from the last 2
    static int choose_random_moves = 0;             /// if the last ship left has only one hit, we randomly choose whether to hit it along the row or along the column
    static int in_if = 0;                           /// it indicates when we are in the if_mode (when hitting around the hit around the last ship, if we don't know its direction)
    static int last_around = 1;                     /// it passes from 'if' to 'if' when we hit around the first hit on the ship (and we DON'T KNOW ITS DIRECTION)
    static int chopin = 0;                          /// our composers help us know if during the last_mode we made our random hits on the same ship and indicate whether the ship is vertical (liszt) or horizontal (chopin)
    static int liszt = 0;
    static int chessboard = 0;                      /// the 'style' of our hits
    static int mode_last = 4;                       /// the mode_last generally helps us pass from step to step when we hit the last 2 ships
    static int count_the_last_2_random_hits = 0;    /// it describes its use...
    static int directions_found = 0;                /// so does it...
    static Place last_board [10];                   /// the board where we put some of the hits of the last 2 ships
    static int in_searching = 0;                    /// it indicates whether we are still searching the direction of the last 2 ships or not
    static int last_ships_found = 0;                /// when we have made the random hits (in the last_mode) on the same ship, it indicates when we have found another ship
    static int not_fucked = 1;                      /// if not_fucked == 1, we know the direction of the ship which moves. If it is '== 0', we fucked up, because we don't know it's direction
    static int ship2_ship3 = 0;                     /// it warns us if the last 2 ships are the 2ble and one 3ple
    static int ship2_ship3_hits = 1;                /// it counts the random hits on the last (ONLY IF THEY ARE 2ble and 3ple) ships (it saves our lives when the 2ble and 3ple are on the same row or column)
    static int prelast_known_directions = 0;        /// it is activated if we have made at least 2 random hits on the prelast ship, in order not to search around the prelast ship (since we know its direction)
    static int not_again1 = 0;                      /// in order to go only once in a specific 'if'
    static int not_again2 = 0;                      /// (same)
    static int not_again3 = 0;                      /// (same)
    static int go_down = 0;                         /// (same)
    static int change_chessboard = 0;               /// when we run out of our chessboard's empties, we have to change our style of hitting
    static int count_my_last_moves = 0;             /// so as to know when the ship is POSSIBLY still
    static int last_horizontal = 1;                 /// same with the 'horizontal' but for the last ship
    static int last_vertical = 1;                   /// same with the 'vertical' but for the last ship
    static int last_round1 = 0;                     /// same with the 'round1' but for the last ship
    static int last_round2 = 0;                     /// same with the 'round2' but for the last ship
    static int last_round3 = 0;                     /// last_round3, last_round4 are used in special occasions to hit the last ship in a same way as last_round1
    static int last_round4 = 0;
    static int last_round_double = 0;
    static int wrong_assumption1 = 0;               /// (it is commented in the function)
    static int wrong_assumption2 = 0;               /// (it is commented in the function)
    static int wrong_direction = 0;                 /// if we found the wrong direction of the 2ble ship when we are in ship2_ship3_mode
    static int last_round_search1 = 0;              /// for searching the line of the last ship
    static int last_round_search2 = 9;
    static int last_round_search3 = 0;
    static int last_round_search4 = 9;
    static int last_round_search5 = 0;
    static int last_round_search6 = 9;
    static int last_round_search7 = 0;
    static int last_round_search8 = 9;
    static int change_completed = 0;                /// activated when we have changed the chessboard and we have made our first move
    static int where_is_the_double = 0;             /// activated in a special occasion of the 2ble_3ple_mode
    static int searching_2ble_3ple_same_line = 1;   /// (it is commented in the function)
    static int last_board_changed = 0;              /// becomes =1 in order not to change the last_board more than 1 time when needed
    static int record_once = 0;                     /// it describes its use...
    static Place all_hits[40];                      /// records all the hits on the first 6 ships
    static Place special_board[20];                 /// used to record specific hits in order to know their Places when we understand that the last 2 ships were considered as one


/* It returns a Place (x, y) of the next hit
The input board is the players perception of the other board
i.e. what has he hit till now (fails & hits)
The opponentDeadShips variable is a table of size 7,
each place of which contains 1 for an opponent's destroyed
ship and 0 otherwise,
The lastPoint is a Place {(x,y) symbol} and stands for the
last point the player has hit.
For the first move it will be x = -1, y = -1 and symbol = ' '
*/
extern Place hit_9708_9626(Board *b, char *ODS, Place L){

    Place ret;

    /// ODS == opponentDeadShips
    /// Last Point = L

    if (!tries)                      ///firstly we choose our 'style' (Q2)
        chessboard = rand() % 2;

    tries++;

    if (tries > 200){                   ///we change here our 'style' when needed (Q3)
        int g, v, count_emptys = 0;
        for (g = 0; g < BOARD_SIZE; g++){
            for (v = 0; v < BOARD_SIZE; v++){
                if ((v + g) % 2 == chessboard && b->board[g][v].symbol == EMPTY_SYMBOL){
                    count_emptys++;
                }
            }
        }
        if (!count_emptys){
            change_chessboard = 1;
        }
    }


    if (L.x == -1 && L.y == -1){    ///Q4
        last_board[3] = L;
        ret.x = 0;
        ret.y = 0;
        return ret;
    }

    int v, count_alives = 0;            /// checks how many ships are still alive (Q5)
    for (v = 0; v < 7; v++){
        if (ODS[v] == 0)
            count_alives++;
    }

    if (count_alives == 2 && mode_last == 4)   /// if the ships left are 2, we go to mode_last (Q6)
        mode_last = 1;


    if (count_alives == 2 && ODS[0] == 0 && (ODS[1] == 0 || ODS[2] == 0)){   /// if the last 2 ships are a 2ble and a 3ple, ship2_ship3_mode is activated (Q7)
        ship2_ship3 = 1;
    }


    if (ODS[0] == 1 && ODS[1] == 1 && ODS[2] == 1 && ODS[3] == 1 && ODS[4] == 1 && ODS[5] == 1 && ODS[6] == 0)   ///in the ifs under, we check the size of the last ship (Q8)
        N = 9;

    if (ODS[0] == 1 && ODS[1] == 1 && ODS[2] == 1 && ODS[3] == 1 && ODS[4] == 1 && ODS[5] == 0 && ODS[6] == 1)
        N = 7;

    if ((ODS[0] == 1 && ODS[1] == 1 && ODS[2] == 1 && ODS[3] == 1 && ODS[4] == 0 && ODS[5] == 1 && ODS[6] == 1) || (ODS[0] == 1 && ODS[1] == 1 && ODS[2] == 1 && ODS[3] == 0 && ODS[4] == 1 && ODS[5] == 1 && ODS[6] == 1))
        N = 5;

    if ((ODS[0] == 1 && ODS[1] == 1 && ODS[2] == 0 && ODS[3] == 1 && ODS[4] == 1 && ODS[5] == 1 && ODS[6] == 1) || (ODS[0] == 1 && ODS[1] == 0 && ODS[2] == 1 && ODS[3] == 1 && ODS[4] == 1 && ODS[5] == 1 && ODS[6] == 1))
        N = 3;

    if (ODS[0] == 0 && ODS[1] == 1 && ODS[2] == 1 && ODS[3] == 1 && ODS[4] == 1 && ODS[5] == 1 && ODS[6] == 1)
        N = 2;



    if (mode_last == 2 && L.symbol == HIT_SYMBOL){      ///To record the first 2 random hits on the last 2 ships (Q9)
        hits_board[++i] = L;
        last_board[k++] = L;
        special_board[z++] = L;
        mode_last = 1;
        count_the_last_2_random_hits++;
    }

    else if (mode_last == 2 && L.symbol == MISS_SYMBOL)     ///Go to random again (Q10)
        mode_last = 1;

    if (count_the_last_2_random_hits == 2 && mode_last == 1) ///Go to search around each hit point (Q11)
        mode_last = 3;

    if (ship2_ship3_hits == 3 && !change_chessboard && !last_board_changed){   ///check the board so as the first ship hit is the double and change it if needed (Q12)

        if (chopin){
            Place temp;
            last_board_changed = 1;

            if (abs(last_board[1].y - last_board[2].y) == 2){
                temp = last_board[1];
                last_board[1] = last_board[0];
                last_board[0] = temp;
            }

            else if (abs(last_board[1].y - last_board[0].y) == 2){
                temp = last_board[1];
                last_board[1] = last_board[2];
                last_board[2] = temp;
            }
        }

        else if (liszt){
            Place temp;
            last_board_changed = 1;

            if (abs(last_board[1].x - last_board[2].x) == 2){
                temp = last_board[1];
                last_board[1] = last_board[0];
                last_board[0] = temp;
            }

            else if (abs(last_board[1].x - last_board[0].x) == 2){
                temp = last_board[1];
                last_board[1] = last_board[2];
                last_board[2] = temp;
            }
        }
    }

    if (mode_last == 1){                          ///The random hits (Q13)

        while(1) {

            ret.x = rand() % b->width;
            ret.y = rand() % b->height;

            if ((ret.y + ret.x) % 2 == chessboard) {

                if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                break;
            }
        }
    mode_last = 2;
    return ret;
    }

    if ((last_board[0].x == last_board[1].x) && (abs(last_board[0].y - last_board[1].y) < 9) && count_alives == 2)        ///the random hits are on the same ship and the ship is horizontal (Q14)
        chopin = 1;


    if ((last_board[0].y == last_board[1].y) && (abs(last_board[0].x - last_board[1].x) < 9) && count_alives == 2)        ///the random hits are on the same ship and the ship is vertical (Q15)
        liszt = 1;



    if(!N && (chopin||liszt) && count_alives == 2 && !last_ships_found){       ///if the random hits are on the same ship or on ships in a row (Q16)

        if (L.symbol == HIT_SYMBOL){

            int r, check_hit = 0;
            for (r = 0; r <= (m - 1); r++){                           ///check if the last hit you made is a hit recorded (from the first 5) and make an other one
                if (L.x == all_hits[r].x && L.y == all_hits[r].y){
                    check_hit++;
                    break;
                }
            }

            if((L.x == last_board[0].x && chopin && abs(last_board[0].y - L.y) < 9) || (L.y == last_board[0].y && liszt && abs(last_board[0].x - L.x) < 9) && ship2_ship3_hits <= 3){   ///(Q16.1)

                if (ship2_ship3){
                    ship2_ship3_hits++;
                }

                if (last_round_double == 1)             ///if we mistakenly assumed the direction of the 2ble ship
                    wrong_assumption1 = 1;


                while(ship2_ship3_hits < 3 && !change_chessboard) {

                    if (!not_again1)
                        special_board[z++] = L;

                    ret.x = rand() % b->width;
                    ret.y = rand() % b->height;

                    if ((ret.y + ret.x) % 2 == chessboard) {

                        if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) {
                            not_again1++;
                            continue;
                        }
                        not_again1 = 0;
                        break;
                    }
                }


                if (change_chessboard && ship2_ship3_hits < 3 && ship2_ship3){          ///if the empties on the board no longer exist and the last hit is made in one of the 2ble or 3ple (Q17)

                    if(chopin){
                        ret.x = last_board[0].x;
                        while (1){
                            ret.y = rand() % b->height;
                            int p;
                            for (p = 0; p < 2; p++){
                                if (ret.y == last_board[p].y){
                                    ret.y = rand() % b->height;
                                    continue;
                                }
                            }
                            break;
                        }
                    }
                    if (liszt){
                        ret.y = last_board[0].y;
                        while (1){
                            ret.x = rand() % b->height;
                            int p;
                            for (p = 0; p < 2; p++){
                                if (ret.x == last_board[p].x){
                                    ret.x = rand() % b->height;
                                    continue;
                                }
                            }
                            break;
                        }
                    }
                }

                if (ship2_ship3_hits >= 3 && !change_completed){      ///when there are only the 2 and 3 left and we have made the third random hit on them, in case they are in the same column or row (Q18)
                    hits_board[++i] = L;
                    last_board[k++] = L;
                    last_ships_found++;
                    mode_last = 3;
                    ret.x = L.x - 1;
                    ret.y = L.y;
                }

                if (change_completed){        ///if the 2ble, 3ple are on the same line, we have hit the 3ple randomly in its middle and while we changed the chessboard, we have hit the 3ple again (if we had hit the 2ble again, we would be already in moving_ship_mode)

                    if (record_once == 0){
                        last_board[2] = L;
                        record_once++;
                    }

                    if (chopin && (abs(last_board[2].y - last_board[0].y) > 1) && !wrong_assumption1){
                        ret.x = L.x;
                        ret.y = last_board[0].y - 1;
                        last_round_double++;
                        if (ret.y < 0){
                            ret.y = last_board[0].y + 1;
                        }

                        where_is_the_double = 1;
                    }


                    else if (chopin && (abs(last_board[2].y - last_board[0].y) <= 1) && !wrong_assumption1){
                        ret.x = L.x;
                            ret.y = last_board[1].y - 1;
                            last_round_double++;
                            if(ret.y < 0){
                                ret.y = last_board[1].y + 1;
                            }

                        where_is_the_double = 2;
                    }

                    else if (chopin && wrong_assumption1){
                        if (where_is_the_double == 1){
                            ret.y = last_board[0].y;
                            ret.x = last_board[0].x - 1;

                            where_is_the_double = 5;
                        }
                        else if (where_is_the_double == 2){
                            ret.y = last_board[1].y;
                            ret.x = last_board[1].x - 1;

                            where_is_the_double = 6;
                        }

                    }

                    else if (liszt && (abs(last_board[2].x - last_board[0].x) > 1) && !wrong_assumption1){
                        ret.y = L.y;
                            ret.x = last_board[0].x - 1;
                            last_round_double++;
                            if(ret.x < 0){
                                ret.x = last_board[0].x + 1;
                            }

                        where_is_the_double = 3;
                    }

                    else if (liszt && (abs(last_board[2].x - last_board[0].x) <= 1) && !wrong_assumption1){
                        ret.y = L.y;
                            ret.x = last_board[1].x - 1;
                            last_round_double++;
                            if(ret.x < 0){
                                ret.x = last_board[1].x + 1;
                            }

                        where_is_the_double = 4;
                    }

                    else if (liszt && wrong_assumption1){
                        if (where_is_the_double == 3){
                            ret.x = last_board[0].x;
                            ret.y = last_board[0].y - 1;

                            where_is_the_double = 7;
                        }
                        else if (where_is_the_double == 4){
                            ret.x = last_board[1].x;
                            ret.y = last_board[1].y - 1;

                            where_is_the_double = 8;
                        }
                    }
                }
                return ret;
            }

            else if (check_hit){
                if(chopin){
                    ret.x = last_board[0].x;
                    while (1){
                        ret.y = rand() % b->height;
                        int p;
                        for (p = 0; p < 2; p++){
                            if (ret.y == last_board[p].y){
                                ret.y = rand() % b->height;
                                continue;
                            }
                        }
                        break;
                    }
                }

                if (liszt){
                    ret.y = last_board[0].y;
                    while (1){
                        ret.x = rand() % b->width;
                        int p;
                        for (p = 0; p < 2; p++){
                            if (ret.x == last_board[p].x){
                                ret.x = rand() % b->height;
                                continue;
                            }
                        }
                        break;
                    }
                }
                return ret;
            }

            else if (!check_hit){                              ///record the position (Q16.2)
                hits_board[++i] = L;
                last_board[k++] = L;
                last_ships_found++; ///we found it
                mode_last = 3;
            }
        }

        else if (L.symbol == MISS_SYMBOL){      ///continue searching until you find the other ship (Q19)

                while(!change_chessboard) {

                    ret.x = rand() % b->width;
                    ret.y = rand() % b->height;

                    if (ship2_ship3 && ship2_ship3_hits == 2 && chopin && searching_2ble_3ple_same_line){
                        ret.x = last_board[0].x;
                        ret.y = rand() % b->width;

                        int t, count_last_emptys = 0;
                        for (t = 0; t < BOARD_SIZE; t++){
                            if ((last_board[0].x + t) % 2 == chessboard && b->board[last_board[0].x][t].symbol == EMPTY_SYMBOL){
                                count_last_emptys++;
                            }
                        }
                        if (!count_last_emptys)                   /// if the layout of the 2ble and 3ple is of shape 'Γ' or 'T' and they are not on the same line
                            searching_2ble_3ple_same_line = 0;
                    }

                    if (ship2_ship3 && ship2_ship3_hits == 2 && liszt && searching_2ble_3ple_same_line){
                        ret.y = last_board[0].y;
                        ret.x = rand() % b->width;

                        int r, count_last_emptys = 0;
                        for (r = 0; r < BOARD_SIZE; r++){
                            if ((last_board[0].y + r) % 2 == chessboard && b->board[r][last_board[0].y].symbol == EMPTY_SYMBOL){
                                count_last_emptys++;
                            }
                        }
                        if (!count_last_emptys)
                            searching_2ble_3ple_same_line = 0;
                    }

                    if ((ret.y + ret.x) % 2 == chessboard) {

                        if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                        break;
                    }
                }

            if (ship2_ship3_hits == 2 && change_chessboard){         ///if the empties no longer exist, we change the chess board and we hit on the row or column where we found the last 2 hits (Q20)

                change_completed = 1;

                if(chopin){
                    ret.x = last_board[0].x;
                    while (1){
                        ret.y = rand() % b->height;
                        int p;
                        for (p = 0; p < 2; p++){
                            if (ret.y == last_board[p].y){
                                ret.y = rand() % b->height;
                                continue;
                            }
                        }
                        if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                            break;

                        else{                                       ///in case there are no empties on the line, we change direction (Q20.1)

                            ret.y = last_board[0].y;
                            if (last_round_search5 < 10){
                                wrong_direction = 1;
                                ret.x = 2 * last_round_search5;
                                last_round_search5++;
                                return ret;
                            }
                            else if (last_round_search5 == 10 && last_round_search6 >= 0){
                                ret.x = 2 * last_round_search6 + 1;
                                last_round_search6--;
                                return ret;
                            }

                        }
                        return ret;
                    }
                }

                if (liszt){
                    ret.y = last_board[0].y;
                    while (1){
                        ret.x = rand() % b->width;
                        int p;
                        for (p = 0; p < 2; p++){
                            if (ret.x == last_board[p].x){
                                ret.x = rand() % b->height;
                                continue;
                            }
                        }
                        if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                            break;
                        else{                                               ///in case there are no empties on the line, we change direction (Q20.1)

                            ret.x = last_board[0].x;
                            if (last_round_search5 < 10){
                                wrong_direction = 1;
                                ret.y = 2 * last_round_search5;
                                last_round_search5++;
                                return ret;
                            }
                            else if (last_round_search5 == 10 && last_round_search6 >= 0){
                                ret.y = 2 * last_round_search6 + 1;
                                last_round_search6--;
                                return ret;
                            }
                        }
                        return ret;
                    }
                }
            }

            if (ship2_ship3_hits == 3 && change_completed){

                    last_board[++k] = L;
                    hits_board[++i] = L;

                    if (where_is_the_double == 1){
                        ret.x = L.x;
                        ret.y = last_board[0].y + 1;
                    }

                    else if (where_is_the_double == 2){
                        ret.x = L.x;
                        ret.y = last_board[1].y + 1;
                    }

                    else if (where_is_the_double == 3){
                        ret.y = L.y;
                        ret.x = last_board[0].x + 1;
                    }
                    else if (where_is_the_double == 4){
                        ret.y = L.y;
                        ret.x = last_board[1].x + 1;
                    }

                    else if (where_is_the_double == 5){
                        ret.y = L.y;
                        ret.x = last_board[0].x + 1;
                    }

                    else if (where_is_the_double == 6){
                        ret.y = L.y;
                        ret.x = last_board[1].x + 1;
                    }

                    else if (where_is_the_double == 7){
                        ret.x = L.x;
                        ret.y = last_board[0].y + 1;
                    }

                    else if (where_is_the_double == 8){
                        ret.x = L.x;
                        ret.y = last_board[1].y + 1;
                    }
            }
            return ret;
        }
    }

    if ((chopin || liszt) && directions_found == 0 && mode_last == 3 && in_searching == 0 && !wrong_direction){      ///if the first 2 (at least) random hits are on the same ship, we needn't hit around them, because WE KNOW ITS DIRECTION (Q21)
        k++;
        prelast_known_directions++;
        directions_found++;
        q = 1;
    }

    if (L.symbol == HIT_SYMBOL && in_searching == 1 && directions_found < 2 && another_counter > 0){   ///we entry the hits around the random hits on the last 2 ships (the "around" hits are made in the if under) (Q22)


                if (prelast_known_directions)
                    k--;

                    directions_found++;
                    hits_board[++i] = L;
                    last_board[k++] = L;
                    another_counter = 0;
                    dont_do_if = 1;
                    in_searching = 0;
    }

    if (mode_last == 3 && !N && count_alives == 2){         ///searching around the random hits, starting FIRST from the prelast ship and SECONDLY from the last ship (Q23)

            while (directions_found < 2){

                while (last_board[k-2].x - 1 >= 0 && another_counter == 0){

                    ret.x = last_board[k-2].x - 1;
                    ret.y = last_board[k-2].y;
                    another_counter = 1;
                    in_searching = 1;
                    return ret;
                }

                if (last_board[k-2].x == 0 && dont_do_if == 1)
                    another_counter = 1;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (last_board[k-2].x + 1 <= 19 && another_counter == 1){

                    ret.x = last_board[k-2].x + 1;
                    ret.y = last_board[k-2].y;
                    another_counter = 2;
                    in_searching = 1;
                    return ret;
                }

                if (last_board[k-2].x == 19 && dont_do_if == 2)
                    another_counter = 2;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (last_board[k-2].y - 1 >= 0 && another_counter == 2){

                    ret.x = last_board[k-2].x;
                    ret.y = last_board[k-2].y - 1;
                    another_counter = 3;
                    in_searching = 1;
                    return ret;
                }

                if (last_board[k-2].y == 0 && dont_do_if == 3)
                    another_counter = 3;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (last_board[k-2].y + 1 <= 19 && another_counter == 3){

                    ret.x = last_board[k-2].x;
                    ret.y = last_board[k-2].y + 1;
                    another_counter = 4;
                    in_searching = 1;
                    return ret;
                }
            }
            mode_last = 4;
    }

    if (mode_last == 4 && !N && count_alives == 2 && !not_again3){         ///it goes to the BIG while in order to fuck the 6th ship (since we know its direction) PS. it won't work if the last ship hit is the 2ble (obviously) (Q24)
        around = 0;
        random1 = 0;

        if (!prelast_known_directions){                 ///(Q24.1)

            if(hits_board[i].x == hits_board[i-2].x){
                counter = 3;
                horizontal = 1;
            }

            if(hits_board[i].y == hits_board[i-2].y){
                counter = 1;
                vertical = 1;
            }
        }

        else if (prelast_known_directions){             ///(Q24.2)

            if(hits_board[i].x == hits_board[i-1].x){
                counter = 3;
                horizontal = 1;
            }

            if(hits_board[i].y == hits_board[i-1].y){
                counter = 1;
                vertical = 1;
            }
        }
    }

    if (!N && change_chessboard && !ship2_ship3 && !last_ships_found){       /// 2 ships on the same line (we had assumed that they were the same ship) (Q24.3)

        if (chopin){

            ret.x = last_board[0].x;

            if (last_round_search3 < 10){

                while (1){

                    ret.y = 2 * last_round_search3;
                    last_round_search3++;
                    if (last_round_search3 == 11){
                        last_round_search3--;
                        break;
                    }
                    if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                        return ret;
                }
            }
            else if (last_round_search3 == 10 && last_round_search4 >= 0){

                while (last_round_search4 > 0){

                    ret.y = 2 * last_round_search4 + 1;
                    last_round_search4--;
                    if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                        return ret;
                }
                return ret;
            }
        }

        if (liszt){

            ret.y = last_board[0].y;

            if (last_round_search3 < 10){

                while (1){

                    ret.x = 2 * last_round_search3;
                    last_round_search3++;
                    if (last_round_search3 == 11){
                        last_round_search3--;
                        break;
                    }
                    if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                        return ret;
                }
            }
            else if (last_round_search3 == 10){

                while (last_round_search4 > 0){

                    ret.x = 2 * last_round_search4 + 1;
                    last_round_search4--;

                    if (b->board[ret.x][ret.y].symbol == EMPTY_SYMBOL)
                        return ret;
                }
                return ret;
            }
        }
    }

    if (N){                                                             ///here we try to win the game, making our last hits in order to destroy the THAT 7th BASTARD (Q25)

        if (N == 3 && change_completed && last_board[2].x != L.x && last_board[2].y != L.y){
            last_board[2] = L;
            not_fucked = 0;
            Place temp;
            if (abs(last_board[0].y - last_board[2].y) == 1){
                temp = last_board[0];
                last_board[0] = last_board[1];
                last_board[1] = temp;
            }
        }

        if (last_board[3].x == -1 && ship2_ship3_hits == 1){            /// the 4th position is empty
            not_fucked = 0;
        }

        if (wrong_assumption2 && !not_again2){
            not_fucked = 0;
            if (z - 1 >= 0)
                last_board[k-2] = special_board[z - 1];
            else
                last_board[k-2] = special_board[z + 1];

            if (last_board[2].x == last_board[1].x && last_board[2].y == last_board[1].y)
                j = 1;

            not_again2++;
        }

        if (wrong_direction){
            not_fucked = 0;
        }

        while (!not_fucked){                            ///if don't know the direction of the ship that is moving (Q26)

           if(L.symbol == HIT_SYMBOL && in_if){         ///we go here when we find the direction of the ship (that we didn't know before) (Q27)

                int r, check_hit = 0;
                for (r = 0; r <= (m - 1); r++){                           ///check if the last hit you made is a hit recorded (from the first 5) and make an other one
                    if (L.x == all_hits[r].x && L.y == all_hits[r].y){
                        check_hit++;
                        break;
                    }
                }
                if (!check_hit){
                    last_board[k] = L;
                    w = 1;
                    not_fucked = 1;
                    break;
                }
           }

           if (last_around == 1){                      /// searching in order to find the direction (Q28)
                ret.x = last_board[k-2].x;
                ret.y = last_board[k-2].y + 1;
                last_around = 2;
                in_if = 1;
                if (ret.y <= 19)
                    return ret;
            }
            if (last_around == 2){
                ret.x = last_board[k-2].x - 1;
                ret.y = last_board[k-2].y;
                last_around = 3;
                in_if = 1;
                if (ret.x >= 0)
                    return ret;
            }
            if (last_around == 3){
                ret.x = last_board[k-2].x;
                ret.y = last_board[k-2].y - 2;
                last_around = 4;
                in_if = 1;
                if (ret.y >= 0)
                    return ret;
            }
            if (last_around == 4){
                ret.x = last_board[k-2].x + 2;
                ret.y = last_board[k-2].y;
                last_around = 0;
                in_if = 1;
                if (ret.x <= 19)
                return ret;
            }
            if (last_around == 0){                      ///the random hits we make if we are very unlucky and we didn't found the direction in the first 4 moves (Q29)

                if (choose_random_moves == 0){
                    while(1) {
                        ret.x = hits_board[i-1].x;
                        ret.y = rand() % b->height;

                        int p = 0;
                        for (p = 0; p < m - 1; p++){
                            if (ret.x == all_hits[p].x && ret.y == all_hits[p].y){
                                ret.y = rand() % b->height;
                                continue;
                            }
                        }

                        if ((ret.y + ret.x) % 2 == chessboard) {

                            if(b->board[ret.x][ret.y].symbol == HIT_SYMBOL && ret.x != hits_board[i-1].x && ret.y != hits_board[i-1].y) continue;

                            else {
                                choose_random_moves = rand () % 2;
                                break;
                            }
                        }
                    }
                return ret;
                }

                if (choose_random_moves == 1){
                    while(1) {
                        ret.x = rand() % b->width;
                        ret.y = hits_board[i-1].y;

                        int p = 0;
                        for (p = 0; p < m - 1; p++){
                            if (ret.x == all_hits[p].x && ret.y == all_hits[p].y){
                                ret.x = rand() % b->width;
                                continue;
                            }
                        }

                        if ((ret.y + ret.x) % 2 == chessboard) {

                            if(b->board[ret.x][ret.y].symbol == HIT_SYMBOL && ret.x != hits_board[i-1].x && ret.y != hits_board[i-1].y) continue;

                            else {
                                choose_random_moves = rand () % 2;
                                break;
                            }
                        }
                    }
                return ret;
                }
            }
        }

        if(not_fucked) {                                            ///if we know the direction of the ship moving (Q30)

            count_my_last_moves++;

            if (last_board[0 + w - j].x == last_board[2 + w - q - j].x){          ///the last ship is horizontal (Q31)

                int r;
                for (r = 0; r <= (m - 1); r++){                           ///check if the last hit you made is a hit recorded (from the first 5) and make an other one (Q31.1)
                    if (L.x == all_hits[r].x && L.y == all_hits[r].y){
                        ret.x = L.x;
                        while (1){
                            ret.y = L.y + 2*(rand() % 5 - 2);
                            if (ret.y <= 19 && ret.y >= 0 && ret.y != L.y) break;
                        }
                        return ret;
                    }
                }

                if (!round_last){                                       ///only for the first hit (to have a Last Point in the 'if' under)
                    ret.x = last_board[2 + w - q - j].x;

                    if (last_board[2 + w - q - j].y > last_board[0 + w - j].y)
                        ret.y = last_board[2 + w - q - j].y + 1;
                    else
                        ret.y = last_board[0 + w - j].y + 1;

                    round_last++;
                    if (ret.y <= 19) return ret;
                    else {
                        ret.y -= 2;
                        return ret;
                    }
                }

                else if (L.symbol == MISS_SYMBOL && round_last && count_my_last_moves <= 20){ ///(Q31.2)
                    ret.x = L.x;
                        while (1){

                            ret.y = L.y + 2 * (rand() % 3 - 1);

                            if (ret.y == L.y) continue;

                            if (ret.y <= 19 && ret.y >= 0) break;
                        }
                    return ret;
                }

                else if (L.symbol == HIT_SYMBOL && round_last && count_my_last_moves <= 20){    ///(Q32)

                    ret.x = L.x;

                    while (1){

                        if (N < 7)
                            ret.y = L.y + rand() % N - N/2;
                        else
                            ret.y = L.y + rand() % 5 - 2;

                        if (ret.y <= 19 && ret.y >= 0) break;
                    }
                return ret;
                }

                else if (count_my_last_moves > 20){         ///(Q33)

                    if (L.symbol == MISS_SYMBOL){

                            ret.x = L.x;

                            if (last_round_search1 < 10){
                                ret.y = 2 * last_round_search1;
                                last_round_search1++;
                                return ret;
                            }
                            else if (last_round_search1 == 10){
                                ret.y = 2 * last_round_search2 + 1;
                                last_round_search2--;
                                if (last_round_search2 == -1){
                                    last_round_search1 = 0;
                                    last_round_search2 = 9;
                                }
                                return ret;
                            }
                    }

                    if (L.symbol == HIT_SYMBOL){


                        while (last_horizontal == 1){

                            ret.y = L.y - 1;
                            ret.x = L.x;

                            if (L.symbol == MISS_SYMBOL){
                               ret.x = L.x;
                               ret.y = L.y + 1;
                               last_horizontal = 2;
                            }

                            if (ret.y >= 0)
                                return ret;

                            else last_horizontal = 3;
                        }


                        while (last_horizontal == 2){

                            ret.y = L.y + 1;
                            ret.x = L.x;

                            if (ret.y <= 19){
                                return ret;
                            }
                            else
                                last_horizontal = 4;
                        }

                        while (last_horizontal == 3){
                            ret.y = L.y + last_round1 + 1;
                            ret.x = L.x;
                            last_round1++;
                            if (ret.y <= 19)
                                return ret;
                            else {
                                ret.y = L.y - 1;
                                return ret;
                            }
                        }

                        while (last_horizontal == 4){               ///if we haven't found yet the ship missing but we know it's direction...
                            ret.y = last_board[1].y - last_round3 - 1;
                            ret.x = last_board[1].x;
                            last_round3++;

                            if (ret.y >= 0)
                                return ret;

                            else{
                                last_round3 = 0;
                                last_horizontal = 5;
                            }
                        }

                        while (last_horizontal == 5){
                            ret.y = last_board[1].y + last_round3 + 1;
                            ret.x = last_board[1].x;

                            if (ret.y <= 19)
                                return ret;

                            else{
                                ret.y = rand() % b->width;
                                return ret;
                            }
                        }
                    }
                }
            }

            else if (last_board[0 + w - j].y == last_board[2 + w - q - j].y){   ///if last ship is vertical (Q34)

                int r;
                for (r = 0; r <= (m - 1); r++){                     ///check if the last hit you made is a hit recorded (from the first 5) and make an other one
                    if (L.x == all_hits[r].x && L.y == all_hits[r].y){
                        ret.y = L.y;
                        while (1){

                            ret.x = L.x + 2*(rand() % 5 - 2);
                            if (ret.x <= 19 && ret.x >= 0 && ret.x != L.x) break;
                        }
                    return ret;
                    }
                }

                count_my_last_moves++;

                if (!round_last){                           ///only for the first time
                    ret.y = last_board[2 + w - q - j].y;

                    if (last_board[2 + w - q - j].x > last_board[0 + w - j].x)
                        ret.x = last_board[2 + w - q - j].x + 1;
                    else
                        ret.x = last_board[0 + w - j].x + 1;

                    round_last++;

                    if (ret.x <= 19) return ret;

                    else {
                        ret.x -= 2;
                        return ret;
                    }
                }

                else if (L.symbol == MISS_SYMBOL && round_last && count_my_last_moves <= 20){
                    ret.y = L.y;

                    while (1){

                            ret.x = L.x + 2 * (rand() % 3 - 1);

                            if (ret.x == L.x) continue;

                            if (ret.x <= 19 && ret.x >= 0) break;
                        }
                    return ret;
                }



                else if (L.symbol == HIT_SYMBOL && round_last && count_my_last_moves <= 20){
                    ret.y = L.y;

                    while (1){

                        if (N < 7)
                            ret.x = L.x + rand() % N - N/2;
                        else
                            ret.x = L.x + rand() % 5 - 2;

                        if (ret.x <= 19 && ret.x >= 0) break;
                    }
                return ret;
                }

                else if (count_my_last_moves > 20){

                    if (L.symbol == MISS_SYMBOL){

                        ret.y = L.y;

                        if (last_round_search1 < 10){
                            ret.x = 2 * last_round_search1;
                            last_round_search1++;
                            return ret;
                        }
                        else if (last_round_search1 == 10){
                            ret.x = 2 * last_round_search2 + 1;
                            last_round_search2--;
                            if (last_round_search2 == -1){
                                last_round_search1 = 0;
                                last_round_search2 = 9;
                            }
                            return ret;
                        }
                    }


                    if (L.symbol == HIT_SYMBOL){

                        while (last_vertical == 1){

                            ret.x = L.x - 1;
                            ret.y = L.y;

                            if (L.symbol == MISS_SYMBOL){
                               ret.y = L.y;
                               ret.x = L.x + 1;
                               last_vertical = 2;
                            }

                            if (ret.x >= 0){
                                return ret;
                            }

                            else last_vertical = 3;
                        }


                        while (last_vertical == 2){

                            ret.x = L.x + 1;
                            ret.y = L.y;

                            if (ret.x <= 19){
                                return ret;
                            }

                            else
                                last_vertical = 4;
                        }

                        while (last_vertical == 3){
                            ret.x = L.x + last_round2 + 1;
                            ret.y = L.y;
                            last_round2++;
                            if (ret.x <= 19)
                                return ret;
                            else {
                                ret.x = L.x - 1;
                                return ret;
                            }
                        }

                        while (last_vertical == 4){               ///if we haven't found yet the ship missing but we know it's direction...
                            ret.x = last_board[1].x -last_round4 - 1;
                            ret.y = last_board[1].y;
                            last_round4++;

                            if (ret.x >= 0)
                                return ret;

                            else{
                                last_round4 = 0;
                                last_vertical = 5;
                            }
                        }

                        while (last_vertical == 5){
                            ret.x = last_board[1].x + last_round4 + 1;
                            ret.y = last_board[1].y;
                            last_round4++;

                            if (ret.x <= 19)
                                return ret;

                            else{
                                ret.x = rand() % b->width;
                                return ret;
                            }
                        }
                    }
                }
            }
        }
    }


    while(!N && mode_last == 4){                                    ///just hitting until you fuck 5+1 ships (yeah, you still have the last...) (Q35)

       if (L.symbol == HIT_SYMBOL){
            all_hits[m] = L;
            m++;
       }

        while (random1 == 1){                                       ///random hits (Q36)

            if (L.symbol == MISS_SYMBOL){   ///(Q37)

                while(1) {
                    ret.x = rand() % b->width;
                    ret.y = rand() % b->height;

                    if ((ret.y + ret.x) % 2 == chessboard) {

                        if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                        break;
                    }
                }
            return ret;
            }

            else if (L.symbol == HIT_SYMBOL){   ///(Q38)
                random1 = 0;
                hits_board[i] = L;
            }
        }


        while (random1 == 0){                                        ///random hits stop, we go in around_mode (Q39)

            if (in_while == 1 && L.symbol == HIT_SYMBOL){
                around = 0;
                in_while = 0;
            }

            while (around == 1){                                    ///searching around (up, down, left, right) (Q40)

                while (hits_board[i].x - 1 >= 0 && counter == 0){

                    ret.x = hits_board[i].x - 1;
                    ret.y = hits_board[i].y;
                    counter = 1;
                    in_while = 1;
                    return ret;
                }

                if (hits_board[i].x == 0 && dont_do_if == 1)
                    counter = 1;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (hits_board[i].x + 1 <= 19 && counter == 1){

                    ret.x = hits_board[i].x + 1;
                    ret.y = hits_board[i].y;
                    counter = 2;
                    in_while = 1;
                    return ret;
                }

                if (hits_board[i].x == 19 && dont_do_if == 2)
                    counter = 2;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (hits_board[i].y - 1 >= 0 && counter == 2){

                    ret.x = hits_board[i].x;
                    ret.y = hits_board[i].y - 1;
                    counter = 3;
                    in_while = 1;
                    return ret;
                }

                if (hits_board[i].y == 0 && dont_do_if == 3)
                    counter = 3;

                dont_do_if++; /// in order not to go again in the 'if' above

                while (hits_board[i].y + 1 <= 19 && counter == 3){

                    ret.x = hits_board[i].x;
                    ret.y = hits_board[i].y + 1;
                    counter = 4;
                    in_while = 1;
                    return ret;
                }
            }

            while (around == 0){                                        ///around_mode stops (since we know their directions) and fucking_mode starts (Q41)

                if (chopin && counter == 1){                            ///check if the hits which we thought that were on the same ship, are actually on DIFFERENT SHIPS
                    if (L.symbol == HIT_SYMBOL){
                        int t;
                        for (t = 0; t <= z - 1; t++){
                            if (L.x == special_board[t].x && L.y == special_board[t].y){
                                wrong_assumption2 = 1;                  /// we actually have 2 different ships on the same line or in a layout of 'Γ' or 'T'
                                z = t;
                                break;
                            }
                        }
                    }
                }

                if (liszt && counter == 3){
                    if (L.symbol == HIT_SYMBOL){
                        int t;
                        for (t = 0; t <= z - 1; t++){
                            if (L.x == special_board[t].x && L.y == special_board[t].y){
                                wrong_assumption2 = 1;
                                z = t;
                                break;
                            }
                        }
                    }
                }

                if (counter == 1 || counter == 2){              ///for vertical ships (Q42)

                    if (count_alives == 2)
                        not_again3 = 1;

                    while (vertical == 1){                      ///(Q43)

                        ret.x = L.x - 1;
                        ret.y = L.y;

                        if (L.symbol == MISS_SYMBOL){           ///(Q44)
                           ret.y = L.y;
                           ret.x = hits_board[i].x + 1;
                           vertical = 2;
                        }

                        if (hits_board[i].x == 19 && L.symbol == MISS_SYMBOL){   ///(Q45)
                            random1 = 1;
                            vertical = 1;
                            around = 1;
                            counter = 0;
                            round1 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {

                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                        return ret;
                        }

                        else if (ret.x >= 0)
                            return ret;

                        else vertical = 3;
                    }


                    while (vertical == 2){                      ///(Q46)

                        ret.x = L.x + 1;
                        ret.y = L.y;

                        if (ret.x <= 19 && L.symbol == HIT_SYMBOL) {                ///(Q47)
                            return ret;
                        }

                        else {                                  ///(Q48)
                            random1 = 1;
                            vertical = 1;
                            around = 1;
                            counter = 0;
                            round1 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {

                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                        }
                    return ret;
                    }


                    while (vertical == 3){                      ///(Q49)
                        ret.x = hits_board[i].x + round1 + 1;
                        ret.y = L.y;
                        round1++;                         ///counting the positions we have to hit under the hitsBoard[i].x (Q50)

                        if (L.symbol == MISS_SYMBOL){
                            random1 = 1;
                            vertical = 1;
                            around = 1;
                            counter = 0;
                            round1 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {
                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                        }
                    return ret;
                    }
                }



                if (counter == 3 || counter == 4){              ///for horizontal ships (Q51)

                    if (count_alives == 2)
                        not_again3 = 1;

                    while (horizontal == 1){

                        ret.y = L.y - 1;
                        ret.x = L.x;

                        if (L.symbol == MISS_SYMBOL){
                           ret.x = L.x;
                           ret.y = hits_board[i].y + 1;
                           horizontal = 2;
                        }

                        if (hits_board[i].y == 19 && L.symbol == MISS_SYMBOL){

                            random1 = 1;
                            horizontal = 1;
                            around = 1;
                            counter = 0;
                            round2 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {

                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                            return ret;
                        }

                        else if (ret.y >= 0)
                            return ret;

                        else horizontal = 3;

                    }


                    while (horizontal == 2){

                        ret.y = L.y + 1;
                        ret.x = L.x;

                        if (ret.y <= 19 && L.symbol == HIT_SYMBOL){
                            return ret;
                        }

                        else {

                            random1 = 1;
                            horizontal = 1;
                            around = 1;
                            counter = 0;
                            round2 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {

                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                        }
                        return ret;
                    }

                    while (horizontal == 3){
                        ret.y = hits_board[i].y + round2 + 1;
                        ret.x = L.x;
                        round2++;                       ///counting the positions we have to hit under the hitsBoard[i].x

                        if (L.symbol == MISS_SYMBOL){
                            random1 = 1;
                            horizontal = 1;
                            around = 1;
                            counter = 0;
                            round2 = 0;
                            round2 = 0;
                            i++;

                            while(1) {

                                ret.x = rand() % b->width;
                                ret.y = rand() % b->height;

                                if ((ret.y + ret.x) % 2 == chessboard) {

                                    if(b->board[ret.x][ret.y].symbol != EMPTY_SYMBOL) continue;

                                    break;
                                }
                            }
                        }
                        return ret;
                    }
                }
            }
        }
    }
}


/*
- motion: The motion:
- 0 for doing nothing
- 1 for moving forwards 1 step
- -1 for moving backwards 1 step
*/
static int count_moves = 0;

extern void moveShip_9708_9626(int motionSteps, int *ship, int *motion, Board *b, Ships *s){
  char ok = 0;

  while(!ok){                                                               ///find first alive ship (Q52)
    int i = 0, j = 0;
    int currShip = -1, shipOk = 0;
    for(i = 0 ; (i < s->shipsNumber && shipOk == 0); i++){
        shipOk = 0;
                                                                            /// Check if ship is hurt(Q52)
        for(j = 0 ; j < s->ships[i].length ; j++){
            if(s->ships[i].hits[j] == 0){
                shipOk = 1;
                currShip = i;
                break;
            }
        }
    }

    if(shipOk){                                                             ///move the ship (Q53)

        ///2: 4 πίσω - 6 μπροστά (4-1-3-2)
        ///3.1: 3 μπροστά - 1 πίσω - 3 μπροστά - 1 πίσω - 2 μπροστά (3-1-3-1-2)
        ///3.2: το ανάποδο
        ///5.1: 3 μπροστά - 7 πίσω (3--3--4)
        ///5.2: 5 πίσω - 5 μποστά (5--5)
        ///7: 1 πίσω - 7 μπροστά - 2 πίσω (1-7-2)
        ///9: 2 πίσω - 2 μπροστά - 2 πίσω - 2 μπροστά - 2 πίσω (χωρίς)

        if (currShip == 0){     ///last ship -> 2
            count_moves++;
            while (count_moves <= 4){
                *ship = currShip;
                *motion = -1;
                return;
            }
            if (count_moves == 5 || count_moves == 7 || count_moves == 11){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = 1;
            return;
        }

        if (currShip == 1){     ///last ship -> 3.1
            count_moves++;
            while (count_moves <= 3 || (count_moves >= 7 && count_moves <= 9) || count_moves >= 13){
                *ship = currShip;
                *motion = 1;
                return;
            }
            if (count_moves == 4 || count_moves == 6 || count_moves == 10 || count_moves == 12){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = -1;
            return;
        }

        if (currShip == 2){     ///last ship -> 3.2
            count_moves++;
            while (count_moves <= 3 || (count_moves >= 7 && count_moves <= 9) || count_moves >= 13){
                *ship = currShip;
                *motion = -1;
                return;
            }
            if (count_moves == 4 || count_moves == 6 || count_moves == 10 || count_moves == 12){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = 1;
            return;
        }

        if (currShip == 3){     ///last ship -> 5.1
            count_moves++;
            while (count_moves <= 3){
                *ship = currShip;
                *motion = 1;
                return;
            }
            if (count_moves == 4 || count_moves == 5 || count_moves == 9 || count_moves == 10){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = -1;
            return;
        }

        if (currShip == 4){     ///last ship -> 5.2
            count_moves++;
            while (count_moves <= 5){
                *ship = currShip;
                *motion = -1;
                return;
            }
            if (count_moves == 6 || count_moves == 7){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = 1;
            return;
        }

        if (currShip == 5){     ///last ship -> 7
            count_moves++;
            while (count_moves >= 3 && count_moves <= 9){
                *ship = currShip;
                *motion = 1;
                return;
            }
            if (count_moves == 2 || count_moves == 10){
                *ship = currShip;
                *motion = 0;
                return;
            }
            *ship = currShip;
            *motion = -1;
            return;
        }

        if (currShip == 6){     ///last ship -> 9
            count_moves++;
            while (count_moves <= 2 || (count_moves >= 5 && count_moves <= 6) || (count_moves >= 9 && count_moves <= 10)){
                *ship = currShip;
                *motion = -1;
                return;
            }
            *ship = currShip;
            *motion = 1;
            return;
        }
    }
    *motion = 0;
  }
}

/* This is a function to reset all the variables you have created
Also allocated memory should be freed in this function
This function will run every time a game ends
*/
extern  void reset_variables_9708_9626(){
    i = 0;
    N = 0;
    k = 0;
    w = 0;
    q = 0;
    z = 0;
    j = 0;
    m = 0;
    tries = 0;
    in_while = 0;
    random1 = 1;
    vertical = 1;
    horizontal = 1;
    around = 1;
    counter = 0;
    round1 = 0;
    round2 = 0;
    dont_do_if = 1;
    round_last = 0;
    another_counter = 0;
    choose_random_moves = 0;
    in_if = 0;
    last_around = 1;
    chopin = 0;
    liszt = 0;
    chessboard = 0;
    mode_last = 4;
    count_the_last_2_random_hits = 0;
    directions_found = 0;
    in_searching = 0;
    last_ships_found = 0;
    not_fucked = 1;
    ship2_ship3 = 0;
    ship2_ship3_hits = 1;
    prelast_known_directions = 0;
    count_moves = 0;
    change_chessboard = 0;
    count_my_last_moves = 0;
    last_horizontal = 1;
    last_vertical = 1;
    last_round1 = 0;
    last_round2 = 0;
    last_round3 = 0;
    last_round4 = 0;
    not_again1 = 0;
    not_again2 = 0;
    not_again3 = 0;
    change_completed = 0;
    searching_2ble_3ple_same_line = 1;
    last_board_changed = 0;
    where_is_the_double = 0;
    last_round_double = 0;
    last_round_search1 = 0;
    last_round_search2 = 9;
    last_round_search3 = 0;
    last_round_search4 = 9;
    last_round_search5 = 0;
    last_round_search6 = 9;
    last_round_search7 = 0;
    last_round_search8 = 9;
    go_down = 0;
    last_board[3].x = -1;
    record_once = 0;
    wrong_assumption1 = 0;
    wrong_assumption2 = 0;
    wrong_direction = 0;
}
