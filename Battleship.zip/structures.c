#include "structures.h"

extern void printShip(Ship *s){
  printf("Ship:\n");
  printf("\tLength: %d", s->length);
  printf("\tPlace: (%d, %d) - (%d, %d)\n", s->start.x, s->start.y, s->end.x, s->end.y);
  int i;
  printf("\tHits: ");
  for(i = 0 ; i < s->length ; i++)
    printf("%d", s->hits[i]);
  putchar('\n');
}

extern void printShips(Ships *s){
  int i = 0;
  for(i = 0 ; i < s->shipsNumber ; i++)
    printShip(&s->ships[i]);
}

extern char checkEndGame(Ships *s){
  char done = 1;
  int i;
  for(i = 0 ; (i < s->shipsNumber) && (done == 1) ; i++){
    int j;
    for(j = 0 ; j < s->ships[i].length ; j++){
      if(s->ships[i].hits[j] == 0){
        done = 0;
        break;
      }
    }
  }
  return done;
}

extern char prepareDeadShipsTable(Ships *s, char *deadShips){
  int i;
  for(i = 0 ; i < s->shipsNumber; i++){
    int j;
    deadShips[i] = 1;

    for(j = 0 ; j < s->ships[i].length ; j++){
      if(s->ships[i].hits[j] == 0){
        deadShips[i] = 0;
        break;
      }
    }
  }
}

extern char checkShipHit(Board *b, Place p){
  return (b->board[p.x][p.y].symbol == SHIP_SYMBOL || b->board[p.x][p.y].symbol == HIT_SYMBOL);
}

extern void updateHitShip(Place p, Ships *s){
  int k;
  for(k = 0 ; k < s->shipsNumber ; k++){
    // Check if ship is horizontal
    if(s->ships[k].start.x == s->ships[k].end.x){
      if(p.x == s->ships[k].start.x && s->ships[k].start.y <= p.y && p.y <= s->ships[k].end.y){
        s->ships[k].hits[p.y - s->ships[k].start.y] = 1;
      }
    }
    else if(s->ships[k].start.y == s->ships[k].end.y){
      if(p.y == s->ships[k].start.y && s->ships[k].start.x <= p.x && p.x <= s->ships[k].end.x){
        s->ships[k].hits[p.x - s->ships[k].start.x] = 1;
      }
    }
  }
}

extern char checkInitialShipsSelection(Ships *s, int player){
  //printf("Player %d checks:\n", player);
  int sizes[] = {2, 3, 3, 5, 5, 7, 9};
  int i, j, length;
  // First of all check the number
  if(s->shipsNumber != 7){
    printf(RED "\tShips must be 7!\n" RESET);
    return 0;
  }
  //else printf(GRN "\tNumber of ships correct\n" RESET);

  // Check if the sizes are correct
  for(i = 0 ; i < 7 ; i++){
    // Check declared length
    if(s->ships[i].length != sizes[i]){
      printf(RED "\tShip %d must be of size %d!\n" RESET, i + 1, sizes[i]);
      return 0;
    }

    // Check length from Places
    length = (s->ships[i].end.x - s->ships[i].start.x + s->ships[i].end.y - s->ships[i].start.y) + 1;
    if(length != sizes[i]){
      printf(RED "\tShip %d has erroneous start and end points!\n" RESET, i + 1);
      return 0;
    }

    // Check that places are X or Y aligned
    if(s->ships[i].end.x != s->ships[i].start.x && s->ships[i].end.y != s->ships[i].start.y){
      printf(RED "\tShip %d is not aligned in X nor in Y!\n" RESET, i + 1);
      return 0;
    }

    // Check that ship places are in the board
    char test1 = s->ships[i].start.x < 0 || s->ships[i].start.x >= BOARD_SIZE;
    char test2 = s->ships[i].end.x < 0 || s->ships[i].end.x >= BOARD_SIZE;
    char test3 = s->ships[i].start.y < 0 || s->ships[i].start.y >= BOARD_SIZE;
    char test4 = s->ships[i].end.y < 0 || s->ships[i].end.y >= BOARD_SIZE;

    if(test1 || test2 || test3 || test4){
      printf(RED "\tShip %d was declared out of bounds!\n" RESET, i + 1);
      return 0;
    }
    //printf(GRN "\tShip %d ok\n" RESET, i + 1);
  }

  // Check if a ship collides with another
  for(i = 0 ; i < s->shipsNumber ; i++){
    for(j = 0 ; j < s->shipsNumber ; j++){
      if(i == j) continue;

      int s1bx = s->ships[i].start.x;
      int s1ex = s->ships[i].end.x;
      int s1by = s->ships[i].start.y;
      int s1ey = s->ships[i].end.y;

      int s2bx = s->ships[j].start.x;
      int s2ex = s->ships[j].end.x;
      int s2by = s->ships[j].start.y;
      int s2ey = s->ships[j].end.y;

      char test1 = (s1bx >= s2bx) && (s1bx <= s2ex);
      char test2 = (s1ex >= s2ex) && (s1bx <= s2ex);
      char test3 = (s1by >= s2by) && (s1by <= s2ey);
      char test4 = (s1ey >= s2ey) && (s1by <= s2ey);

      if((test1 || test2) && (test3 || test4)){
        printf(RED "\tShips %d and %d collide!\n" RESET, i + 1, j + 1);
        return 0;
      }
    }
  }
  //printf(GRN "\tShips are free of collisions\n" RESET);
  return 1;
}

extern char canPlayerMoveShip(Ships *s){
  int destroyedShips = s->shipsNumber;
  int i;
  for(i = 0 ; i < s->shipsNumber ; i++){
    int j;
    for(j = 0 ; j < s->ships[i].length ; j++){
      if(s->ships[i].hits[j] == 0){
        destroyedShips--;
        break;
      }
    }
  }
  if(GAMES_TO_RUN == 1)
    printf("Destroyed ships are %d\n", destroyedShips);
  if(destroyedShips >= s->shipsNumber - 1) return 1;
  else return 0;                          // No movement allowed
}

/* Motion can be:
- -1 for doing nothing
- 0 for turning
- 1 for moving forwards 1 step
- 2 for moving forwards 2 steps
- 3 for moving backwards 1 step
- 4 for moving backwards 2 steps

Returns -1 for invalid selections
*/
extern int implementShipMotion(Board *b, Ships *s, int shipId, int motion, int allowedMotion){
  // Check if the ship is valid id
  if(shipId < 0 || shipId > 6){
    printf("Player tries to move an unknown ship.\n");
    return -1;
  }

  // Check the motion
  if(allowedMotion == 1 && (motion < -1 || motion > 1)){
    printf("Player tries to make an invalid motion.\n");
    return -1;
  }

  // Check if the ship isn't hit
  int i;
  int notHit = 0;
  for(i = 0 ; i < s->ships[shipId].length ; i++){
    if(s->ships[shipId].hits[i] == 0){
      notHit = 1;
      break;
    }
  }
  if(notHit == 0){
    printf("Player selected a destroyed ship to move.\n");
    return -1;
  }

  // Check if the motion is ok
  int shipBeginX = s->ships[shipId].start.x;
  int shipBeginY = s->ships[shipId].start.y;
  int shipEndX = s->ships[shipId].end.x;
  int shipEndY = s->ships[shipId].end.y;

  // CHECK BACKWARD MOTION BY 1
  if(motion == -1)
  {
    // That's for horizontal ships
    if(shipBeginY == shipEndY){
      if(shipBeginX - 1 < 0 || b->board[shipBeginX - 1][shipBeginY].symbol == SHIP_SYMBOL  || b->board[shipBeginX - 1][shipBeginY].symbol == HIT_SYMBOL){
        printf(RED "1/Player ship motion collides with another ship or is out of bounds.\n" RESET);
        return -1;
      }

      // make the motion
      //printf("Moving 1 backwards / horizontal\n");
      s->ships[shipId].start.x -= 1;
      s->ships[shipId].end.x -= 1;
      b->board[shipEndX][shipEndY].symbol = EMPTY_SYMBOL;

      int j;
      for(j = 0 ; j < s->ships[shipId].length ; j++){
        if(s->ships[shipId].hits[j] == 0)
          b->board[shipBeginX - 1 + j][shipBeginY].symbol = SHIP_SYMBOL;
        else
          b->board[shipBeginX - 1 + j][shipBeginY].symbol = HIT_SYMBOL;
      }

    }
    else{ // That's for vertical ships
      if(shipBeginY - 1 < 0 || b->board[shipBeginX][shipBeginY - 1].symbol == SHIP_SYMBOL || b->board[shipBeginX][shipBeginY - 1].symbol == HIT_SYMBOL){
        printf(RED "2/Player ship motion collides with another ship or is out of bounds.\n" RESET);
        return -1;
      }

      // make the motion
      //printf("Moving 1 backwards / vertical\n");
      s->ships[shipId].start.y -= 1;
      s->ships[shipId].end.y -= 1;
      b->board[shipEndX][shipEndY].symbol = EMPTY_SYMBOL;

      int j;
      for(j = 0 ; j < s->ships[shipId].length ; j++){
        if(s->ships[shipId].hits[j] == 0)
          b->board[shipBeginX][shipBeginY - 1 + j].symbol = SHIP_SYMBOL;
        else
          b->board[shipBeginX][shipBeginY - 1 + j].symbol = HIT_SYMBOL;
      }
    }


  }
    // CHECK FOR FORWARD MOTION BY 1
  else if (motion == 1)
  {
    // That's for horizontal ships
    if(shipBeginY == shipEndY){
      if(shipEndX + 1 >= BOARD_SIZE || b->board[shipEndX + 1][shipEndY].symbol == SHIP_SYMBOL || b->board[shipEndX + 1][shipEndY].symbol == HIT_SYMBOL){
        printf("3/Player ship motion collides with another ship or is out of bounds.\n");
        return -1;
      }

      // make the motion
      //printf("Moving 1 forward / horizontal\n");
      s->ships[shipId].start.x += 1;
      s->ships[shipId].end.x += 1;
      b->board[shipBeginX][shipBeginY].symbol = EMPTY_SYMBOL;

      int j;
      for(j = 0 ; j < s->ships[shipId].length ; j++){
        if(s->ships[shipId].hits[j] == 0)
          b->board[shipBeginX + 1 + j][shipBeginY].symbol = SHIP_SYMBOL;
        else
          b->board[shipBeginX + 1 + j][shipBeginY].symbol = HIT_SYMBOL;
      }

    }
    else{ // That's for vertical ships
      if(shipEndY + 1 >= BOARD_SIZE || b->board[shipEndX][shipEndY + 1].symbol == SHIP_SYMBOL || b->board[shipEndX][shipEndY + 1].symbol == HIT_SYMBOL){
        printf("4/Player ship motion collides with another ship or is out of bounds.\n");
        return -1;
      }

      // make the motion
      //printf("Moving 1 forward / vertical\n");
      s->ships[shipId].start.y += 1;
      s->ships[shipId].end.y += 1;
      b->board[shipBeginX][shipBeginY].symbol = EMPTY_SYMBOL;

      int j;
      for(j = 0 ; j < s->ships[shipId].length ; j++){
        if(s->ships[shipId].hits[j] == 0)
          b->board[shipBeginX][shipBeginY + 1 + j].symbol = SHIP_SYMBOL;
        else
          b->board[shipBeginX][shipBeginY + 1 + j].symbol = HIT_SYMBOL;
      }
    }

  }

}
