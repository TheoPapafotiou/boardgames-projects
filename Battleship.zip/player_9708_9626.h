#include "structures.h"

/* You must declare:
- 1 ship of size 2
- 2 ships of size 3
- 2 ships of size 5
- 1 ship of size 7
- 1 ship of size 9 */
extern Ships setupShips_9708_9626(int boardSize);

/* Must return a Place (x, y) of the next hit
The input board is the players perception of the other board
i.e. what has he hit till now (fails & hits)
The opponentDeadShips variable is a table of size 7,
each place of which contains 1 for an opponent's destroyed
ship and 0 otherwise
*/
extern Place hit_9708_9626(Board *b, char *opponentDeadShips, Place lastPoint);

/* The moveShip function MUST change the 2 integers
- ship: The id of the ship to move [0-7). For no motion, return -1.
- motion: The motion:
  - 0 for doing nothing
  - 1 for moving forwards 1 step
  - -1 for moving backwards 1 step
*/

extern void moveShip_9708_9626(int motionSteps, int *ship, int *motion, Board *b, Ships *s);

/* This is a function to reset all the variables you have created
Also allocated memory should be freed in this function
This function will run every time a game ends
*/
extern  void reset_variables_9708_9626();
