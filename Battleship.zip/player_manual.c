#include "player_manual.h"

/* You must declare:
- 1 ship of size 2
- 2 ships of size 3
- 2 ships of size 5
- 1 ship of size 7
- 1 ship of size 9 */
extern Ships setupShips_manual(int boardSize)
{
  Ships s;
  s.ships = (Ship *)malloc(7 * sizeof(Ship));
  s.shipsNumber = 7;
  int i, k = 0;

  // Declare Ship 1 of size 1
  s.ships[k].length = 2;
  s.ships[k].start.x = 15;
  s.ships[k].start.y = 5;
  s.ships[k].end.x = 16;
  s.ships[k].end.y = 5;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;

  // Declare Ship 1 of size 3
  s.ships[k].length = 3;
  s.ships[k].start.x = 15;
  s.ships[k].start.y = 3;
  s.ships[k].end.x = 17;
  s.ships[k].end.y = 3;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;
  // Declare Ship 2 of size 3
  s.ships[k].length = 3;
  s.ships[k].start.x = 1;
  s.ships[k].start.y = 7;
  s.ships[k].end.x = 1;
  s.ships[k].end.y = 9;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;

  // Declare Ship 1 of size 5
  s.ships[k].length = 5;
  s.ships[k].start.x = 8;
  s.ships[k].start.y = 14;
  s.ships[k].end.x = 8;
  s.ships[k].end.y = 18;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;
  // Declare Ship 2 of size 5
  s.ships[k].length = 5;
  s.ships[k].start.x = 15;
  s.ships[k].start.y = 16;
  s.ships[k].end.x = 19;
  s.ships[k].end.y = 16;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;

  // Declare Ship 1 of size 7
  s.ships[k].length = 7;
  s.ships[k].start.x = 5;
  s.ships[k].start.y = 4;
  s.ships[k].end.x = 11;
  s.ships[k].end.y = 4;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;

  // Declare Ship 1 of size 9
  s.ships[k].length = 9;
  s.ships[k].start.x = 11;
  s.ships[k].start.y = 6;
  s.ships[k].end.x = 11;
  s.ships[k].end.y = 14;
  s.ships[k].hits = (char *)malloc(s.ships[k].length);
  for(i = 0 ; i < s.ships[k].length ; i++) s.ships[k].hits[i] = 0;
  k++;

  return s;
}

/* Must return a Place (x, y) of the next hit
The input board is the players perception of the other board
i.e. what has he hit till now (fails & hits)
The opponentDeadShips variable is a table of size 7,
each place of which contains 1 for an opponent's destroyed
ship and 0 otherwise
The lastPoint is a Place {(x,y) symbol} and stands for the
last point the player has hit.
Note that for the first move it will be x = -1, y = -1 and symbol = ' '
*/
extern Place hit_manual(Board *b, char *opponentDeadShips, Place lastPoint){
  // printf("Opponent's dead ships: ");
  // int i;
  // for(i = 0 ; i < 7 ; i++) printf("%d", opponentDeadShips[i]);
  // putchar('\n');

  //uncomment for debugging
  //printf("%d %d %c\n\n\n", lastPoint.x,   lastPoint.y, lastPoint.symbol);

  Place ret;
  char a, c;
  printf("Gimme position (c c): ");
  scanf("%c %c", &a, &c);
  getchar(); // For \n
  ret.x = a - 'a';
  ret.y = c - 'a';
  printf("Move: %d %d\n", ret.x, ret.y);
  return ret;
}

/* The moveShip function MUST change the 2 integers
- ship: The id of the ship to move [0-7)
- motion: The motion:
- 0 for doing nothing
- 1 for moving forwards 1 step
- -1 for moving backwards 1 step
*/
extern void moveShip_manual(int motionSteps, int *ship, int *motion, Board *b, Ships *s){

}

/* This is a function to reset all the variables you have created
Also allocated memory should be freed in this function
This function will run every time a game ends
*/
extern  void reset_variables_manual(){}
