#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef STRUCTURES_H
#define STRUCTURES_H

#define BOLD   "\x1B[1m"
#define RED   "\x1B[31m"
#define GRN   "\x1B[32m"
#define YEL   "\x1B[33m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define CYN   "\x1B[36m"
#define WHT   "\x1B[37m"
#define RESET "\x1B[0m"

#define BRED   "\x1B[41m"
#define BGRN   "\x1B[42m"
#define BYEL   "\x1B[43m"
#define BBLU   "\x1B[44m"
#define BMAG   "\x1B[45m"
#define BCYN   "\x1B[46m"
#define BWHT   "\x1B[47m"

#define BOARD_SIZE 20
#define GAMES_TO_RUN 100
// #define GAMES_TO_RUN 1
#define MAX_MOVES 20 * 20 * 2
#define MAX_MOTIONS 10

#define SHIP_SYMBOL   '_'
#define HIT_SYMBOL    '*'
#define EMPTY_SYMBOL  ' '
#define MISS_SYMBOL   '-'

struct Place{
    int x, y;
    unsigned char symbol;
};
typedef struct Place Place;

struct Board{
    int width, height;
    Place **board;
};
typedef struct Board Board;

struct Ship{
    int length;
    Place start, end;
    char *hits;
};
typedef struct Ship Ship;

struct Ships{
    int shipsNumber;
    Ship *ships;
};
typedef struct Ships Ships;

extern void printShip(Ship *s);
extern void printShips(Ships *s);
extern char checkEndGame(Ships *s);
extern char prepareDeadShipsTable(Ships *s, char *deadShips);
extern char checkShipHit(Board *b, Place p);
extern char checkInitialShipsSelection(Ships *s, int player);
extern char canPlayerMoveShip(Ships *s);
extern void updateHitShip(Place p, Ships *s);
extern int implementShipMotion(Board *b, Ships *s, int shipId, int motion, int allowedMotion);

#endif
