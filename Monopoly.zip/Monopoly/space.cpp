#include <iostream>

#include "space.h"

// TODO: Implement here the methods of Space
Space()
{

}

void setId(int newId)
{
    id = newId;
}

void setName(string newName)
{
    name = newName;
}

void setType(string newType)
{
    type = newType;
}

void setActionText(string newActionText)
{

    actionText = newActionText;
}

void setRent(int newRent)
{
    rent = newRent;
}

void setBuyingCost(int newBuyCost)
{
    buyCost = newBuyCost;
}

void setOwner(int newOwner)
{
    owner = newOwner;
}

int getId()
{
    return id;
}

string getName()
{
    return name;
}

string getType()
{
    return type;
}

string getActionText()
{
    return actionText;
}

int getRent()
{
    return rent;
}

int getTax()
{
     return tax;
}

int getBuyingCost()
{
    return buyCost;
}

int getOwner()
{
    return owner;
}
