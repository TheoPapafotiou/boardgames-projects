#include <iostream>

#include "actions.h"

using namespace std;

int makeMove(Bank &bank, Player players[], int playerTurn, int diceRoll)
{
    // TODO: Implement this function
    Player currentPlayer = players[playerTurn];
    int prevLoc = currentPlayer.getLocation();


    //Update new location
    int newLoc = prevLoc + diceRoll;

    //If player passes start space
    if(newLoc > 40)
    {
        currentPlayer.giveMoneyToPlayer(200);
        bank.takeMoneyFromBank(200);
        newLoc -= 41;
    }

    currentPlayer.setLocation(newLoc);

    return currentPlayer.getLocation();
}

void makeAction(Bank &bank, Player players[], Space spaces[], int playerTurn, int newSpace)
{
    // TODO: Implement this function
    Player currentPlayer = players[playerTurn];
    Player opponent = players[1-playerTurn];
    Space currentSpace = spaces[newSpace];
    string currentSpaceType = currentSpace.getType();

    if((currentSpaceType == "Property" || currentSpaceType == "RailRoad" || currentSpaceType == "Utility") && currentSpace.getOwner() != playerTurn)
    {
        if(currentSpace.getOwner() == -1 && currentPlayer.getMoney() >= (5 * currentSpace.getBuyingCost())
        {
                currentPlayer.takeMoneyFromPlayer(currentSpace.getBuyingCost());
                bank.giveMoneyToBank(currentSpace.getBuyingCost());
                currentSpace.setOwner(playerTurn);
        }
        else
        {
            currentPlayer.takeMoneyFromPlayer(currentSpace.getRent());
            opponent.giveMoneyToPlayer(currentSpace.getRent());
        }
    }

    else if(currentSpaceType == "Tax")
    {
        currentPlayer.takeMoneyFromPlayer(currentSpace.getTax());
        bank.giveMoneyToFreePark(currentSpace.getTax());
    }

    else if(currentSpaceType == "FreeParking")
    {
        currentPlayer.giveMoneyToPlayer(bank.takeFreeParkMoney());
    }
    else if(currentSpaceType == "GoJail")
    {
        currentPlayer.setLocation(10);
        currentPlayer.takeMoneyFromPlayer(200);
        bank.giveMoneyToFreePark(200);
    }
}
