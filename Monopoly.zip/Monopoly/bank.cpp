#include "bank.h"

// TODO: Implement here the methods of Bank
Bank()
{
    money = 20580;
    freeParkMoney = 0;
}

int  getMoney(){

    return money;

}

int getFreeParkMoney(){

    return freeParkMoney;

}

void giveMoneyToBank(int amount){

    money += amount;

}


void takeMoneyFromBank(int amount){

    money -= amount;

}


void giveMoneyToFreePark(int amount){

    freeParkMoney += amount ;
}

int takeFreeParkMoney(){


    int  temp = freeParkMoney;
    freeParkMoney = 0;
    return temp;
}

