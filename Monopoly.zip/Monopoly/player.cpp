#include <iostream>
#include <sstream>

#include "player.h"

using namespace std;

// TODO: Implement here the methods of Player
Player(int playerId)
{
    money = 1500;
    location = 0;
    if(!id)
    {
        name = "Player 1";
    }
    else
    {
        name = "Player 2";
    }
}

int getId()
{
    return id;
}

int getLocation()
{
    return location;
}

int getMoney()
{
    return money;
}

string getName()
{
    return name;
}

void setLocation(int spaceNum)
{
    location = spaceNum;
}

void giveMoneyToPlayer(int amount)
{
    money += amount;
}

void takeMoneyFromPlayer(int amount)
{
    money -= amount;
}
